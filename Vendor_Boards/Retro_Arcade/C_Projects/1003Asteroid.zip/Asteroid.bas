'Asteroid f�r die Pingpong-Platine

$crystal = 8000000
$regfile = "m8def.dat"
$hwstack = 64
$swstack = 64
$framesize = 64

Dim Leds(12) As Word
Dim X As Byte
Dim Y As Byte
Dim N As Word
Dim U As Word
Dim Licht As Word
Dim Fehler As Byte

Declare Sub Standby
Declare Sub Test
Declare Sub Initialisierung

Open "comb.4:9600,8,n,1,inverted" For Output As #1
Open "comb.5:9600,8,n,1,inverted" For Input As #2


Declare Sub Led1(byval X As Byte , Byval Y As Byte)
Declare Sub Led0(byval X As Byte , Byval Y As Byte)
Declare Sub Laser
Baud = 9600

Initialisierung


Do
Do
Fehler = 0
  For N = 1 To 12
     Leds(n) = 0
  Next N
Waitms 1000
Laser : If Licht > 300 Then Fehler = 1                      'zu fr�h geschossen!

Leds(6) = &B0000100000
Waitms 1000
Laser : If Licht < 300 Then Fehler = 1                      'nicht getroffen ...
Waitms 1000
Leds(5) = &B0000100000
Leds(6) = &B0001110000
Leds(7) = &B0000100000
Laser : If Licht < 300 Then Fehler = 1
Waitms 1000
Leds(3) = &B0000100000
Leds(4) = &B0001110000
Leds(5) = &B0011111000
Leds(6) = &B0111111100
Leds(7) = &B0011111000
Leds(8) = &B0001110000
Leds(9) = &B0000100000
Laser : If Licht < 300 Then Fehler = 1
Waitms 500
Leds(3) = &B0001110000
Leds(4) = &B0011111000
Leds(5) = &B0111111100
Leds(6) = &B0111111100
Leds(7) = &B0111111100
Leds(8) = &B0011111000
Leds(9) = &B0001110000
Laser : If Licht < 300 Then Fehler = 1
Waitms 200

Leds(2) = &B0001110000
Leds(3) = &B0011111000
Leds(4) = &B0111111100
Leds(5) = &B1111111110
Leds(6) = &B1111111110
Leds(7) = &B1111111110
Leds(8) = &B0111111100
Leds(9) = &B0011111000
Leds(10) = &B0001110000
Laser : If Licht < 300 Then Fehler = 1
Waitms 400

If Fehler = 1 Then
  For N = 1 To 12
     Leds(n) = &B1111111111
  Next N
  Waitms 3000
End If

If Fehler = 0 Then

  Leds(1) = &B0000000000
  Leds(2) = &B0001110000
  Leds(3) = &B0011111000
  Leds(4) = &B0111111100
  Leds(5) = &B1111011110
  Leds(6) = &B1110001110
  Leds(7) = &B1111011110
  Leds(8) = &B0111111100
  Leds(9) = &B0011111000
  Leds(10) = &B0001110000
  Leds(11) = &B0000000000
  Leds(12) = &B0000000000
  Waitms 100
  Leds(1) = &B0000000000
  Leds(2) = &B0001110000
  Leds(3) = &B0011111000
  Leds(4) = &B0111011100
  Leds(5) = &B1110001110
  Leds(6) = &B1100000110
  Leds(7) = &B1110001110
  Leds(8) = &B0111011100
  Leds(9) = &B0011111000
  Leds(10) = &B0001110000
  Leds(11) = &B0000000000
  Leds(12) = &B0000000000
  Leds(3) = &B0011111000
  Leds(4) = &B0111011100
  Leds(5) = &B1110001110
  Leds(6) = &B1100000110
  Leds(7) = &B1110001110
  Leds(8) = &B0111011100
  Leds(9) = &B0011111000
  Leds(10) = &B0101111000
  Leds(11) = &B0000000000
  Leds(12) = &B0000000000
  Waitms 100
  Leds(1) = &B1000000001
  Leds(2) = &B0101110100
  Leds(3) = &B0010011000
  Leds(4) = &B0101010100
  Leds(5) = &B0010001000
  Leds(6) = &B1100000110
  Leds(7) = &B1010001010
  Leds(8) = &B0001010000
  Leds(9) = &B0001110000
  Leds(10) = &B0100001000
  Leds(11) = &B1000000010
  Leds(12) = &B0000000000
  Waitms 100
  Leds(1) = &B1000000001
  Leds(2) = &B0100000100
  Leds(3) = &B0010011000
  Leds(4) = &B0100000100
  Leds(5) = &B0010001000
  Leds(6) = &B1100000001
  Leds(7) = &B1010001010
  Leds(8) = &B0000000000
  Leds(9) = &B0000000000
  Leds(10) = &B0100001000
  Leds(11) = &B1000000100
  Leds(12) = &B1000000001
  Waitms 100
  For N = 1 To 12
     Leds(n) = 0
  Next N
  Waitms 2000
End If

Loop Until Fehler = 1

Standby

Loop
                                          'Obere Led-reihe Frei Als Sensor
Do
  Laser
  Licht = Licht / 50
  Y = Low(licht)
  X = 6
  Led1 X , Y
    Waitms 500
Loop



Sub Laser
  Do
  Loop Until Timer2 > 100
  Portc.0 = 0
  Ddrc.0 = 0
  Waitms 1
  Licht = Getadc(0)
   'Print #1 , U
  Ddrc.0 = 1
  Portc.0 = 0
End Sub

For X = 1 To 12
   For Y = 1 To 10
     Led1 X , Y
     Waitms 50
   Next Y
Next X
For X = 1 To 12
   For Y = 1 To 10
     Led0 X , Y
     Waitms 50
   Next Y
Next X




Sub Led1(byval X As Byte , Byval Y As Byte)
 If X < 13 Then
  Select Case Y
    Case 1 : Leds(x).9 = 1
    Case 2 : Leds(x).8 = 1
    Case 3 : Leds(x).7 = 1
    Case 4 : Leds(x).6 = 1
    Case 5 : Leds(x).5 = 1
    Case 6 : Leds(x).4 = 1
    Case 7 : Leds(x).3 = 1
    Case 8 : Leds(x).2 = 1
    Case 9 : Leds(x).1 = 1
    Case 10 : Leds(x).0 = 1
   End Select
  End If
End Sub

Sub Led0(byval X As Byte , Byval Y As Byte)
 If X < 13 Then
  Select Case Y
    Case 1 : Leds(x).9 = 0
    Case 2 : Leds(x).8 = 0
    Case 3 : Leds(x).7 = 0
    Case 4 : Leds(x).6 = 0
    Case 5 : Leds(x).5 = 0
    Case 6 : Leds(x).4 = 0
    Case 7 : Leds(x).3 = 0
    Case 8 : Leds(x).2 = 0
    Case 9 : Leds(x).1 = 0
    Case 10 : Leds(x).0 = 0
   End Select
  End If
End Sub


'******************  Service-Unterprogramme *********************


Sub Initialisierung
  Config Portc = 15                                         'PORTC als AD-Eingang
  Config Portb = Output
  Config Portd = 255
  Config Timer2 = Timer , Prescale = 8
  On Ovf2 Tim2_isr
  Enable Timer2
  Enable Interrupts
  Start Timer2
  Config Adc = Single , Prescaler = 64 , Reference = Off
  Start Adc
  Config Int0 = Low Level                                   'Falling
  On Int0 Int_isr
End Sub


Sub Standby
  Stop Timer2
  Portc = 0
  Portd = 0
  Portb = 0
  Stop Adc
  Ddrd.2 = 0
  Portd.2 = 1
  Enable Int0
  Powerdown
  Ddrd.2 = 1
  Portd.2 = 0
  Start Adc
  Start Timer2
End Sub


Dim Vhelp As Word

Sub Test
      For X = 1 To 12
         Leds(x) = 1023
      Next X
      Waitms 1000
      For X = 1 To 12
         For Y = 1 To 12
            Leds(y) = 0
         Next Y
         Leds(x) = 1023
         Waitms 100
      Next X
      For Y = 1 To 10
         For X = 1 To 12
            Vhelp = Y - 1
            Vhelp = 2 ^ Vhelp
            Leds(x) = Vhelp
         Next X
         Waitms 100
      Next Y
      For X = 1 To 12
         Leds(x) = 0
      Next X
End Sub

Int_isr:
  Disable Int0
Return


'******************************* Interrupt - Display ****************************

Dim Vy As Byte
Dim Col As Byte
Dim Portdout As Byte
Dim Portcout As Byte


Tim2_isr:
 '800 �s
'Timer2 = 56
Col = Col + 1
If Col = 13 Then Col = 1
Vy = Col + 0
Portd = 0
Portb = 0
Portc = 0
If Col = 1 Then Portb.4 = 0 Else Portb.4 = 1
Portb.3 = 1                                                 'cl
Portb.3 = 0
Portb.2 = 1                                                 'Str
Portb.2 = 0
Portdout = Low(leds(vy))
Portcout = Portdout And 15
Portdout = Portdout And 240
Portd = Portdout
Portc = Portcout
Portb = High(leds(vy))
'Waitms 500
Return
End