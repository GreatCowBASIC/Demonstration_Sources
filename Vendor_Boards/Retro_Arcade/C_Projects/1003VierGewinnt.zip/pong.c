/*****************************************************
Compiler            : CodeVisionAVR 2.04.6 Evaluation
Chip type           : ATmega8
Clock frequency     : 8 MHz (int. RC-OSC)
*****************************************************/

//***************************************************
// Spiel "4 gewinnt"
// auf Basis des Franzis-Pingpong
// http://www.elo-web.de/ping-pong-start
// 1 zus�tzlicher Taster erforderlich, 
// Anschluss zwischen PORTD.3 und GND
//***************************************************

#include <mega8.h>
#include <stdio.h>
#include <delay.h>
#include <sleep.h>


#define P_CLK    PORTB.3
#define P_DATA   PORTB.4
#define P_STROBE PORTB.2

#define PIN_KEY      PIND.3          // port pin for input key
#define PULLUP_KEY   PORTD.3         // internal pullup for input key
#define KEY_PRESSED (PIN_KEY == 0)   // input key is pressed
#define KEY_DEBOUNCE  20             // debounce time for input key


#define WIDTH  12  // number of fields in horizontal direction
#define HEIGHT 10  // number of fields in vertical direction
unsigned char ledState[WIDTH*HEIGHT];  // current state of each field

enum { FIELD_FREE = 0, FIELD_PLAYER1, FIELD_PLAYER2 };  // possible states of a field
#define BLINKING 0x80                                   // to set a field blinking, it is ORed with 0x80


flash unsigned int startlogo[WIDTH] = 
{ 0x0000, 0x0060, 0x0070, 0x0078, 0x006C, 0x0066, 0x0063, 0x03FF, 0x03FF, 0x0060, 0x0060, 0x0060 };

flash unsigned int arrowLeftLogo[WIDTH] = 
{ 0x0010, 0x0038, 0x007C, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000 };

flash unsigned int arrowRightLogo[WIDTH] = 
{ 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x007C, 0x0038, 0x0010 };


// show animated start logo on screen
void showStartLogo(void)
{
   unsigned char row, col, y;
   unsigned int mask;

   mask = 0x0200;
   for(row = 0; row < HEIGHT; row++)
   {           
      for(y = 0; y < (HEIGHT - row); y++)
      {
         for(col = 0; col < WIDTH; col++)
         {                             
            if(startlogo[col] & mask)
               ledState[col*HEIGHT + y] = FIELD_PLAYER1;
            else
               ledState[col*HEIGHT + y] = FIELD_FREE;
         }
         delay_ms(40);               
         if(y != (HEIGHT-1-row))
         {
            for(col = 0; col < WIDTH; col++)
            {                             
               ledState[col*HEIGHT + y] = FIELD_FREE;
            }
         }
      }
      mask >>= 1;
   }

   delay_ms(200);
   for(col = 0; col < WIDTH; col++)
   {                             
      for(row = 0; row < HEIGHT; row++)
      {
         ledState[col*HEIGHT + row] |= BLINKING;
      }
   }

}


// show a logo on screen
// pLogo: pointer to array with logo data
// state: 0 = static logo, BLINKING = blinking logo 
void showLogo(flash unsigned int *pLogo, unsigned char state)
{
   unsigned char row, col;
   unsigned int mask;

   for(col = 0; col < WIDTH; col++)
   {
      mask = 0x0001;
      for(row = 0; row < HEIGHT; row++)
      {           
         if(pLogo[col] & mask)
            ledState[col*HEIGHT + row] = FIELD_PLAYER1 | state;
         else
            ledState[col*HEIGHT + row] = FIELD_FREE;
         mask <<= 1;
      }
   }
}


// clear the whole screen, all LEDs off
void clearScreen(void)
{
   unsigned char i;
   
   for(i = 0; i < (WIDTH*HEIGHT); i++)
   {
      ledState[i] = FIELD_FREE;
   }
}


// set controlller in Powerdown mode
void setStandbyMode(void)
{
   TCCR2 &= 0xF8;   //stop Timer2
   PORTC = 0;
   PORTD = 0;
   PORTB = 0;
   ADCSRA &= 0x7F;  // stopADC
   DDRD.2 = 0;
   PORTD.2 = 1;
   GICR |= 0x40;    //enable INT0
   sleep_enable();
   powerdown();
   PULLUP_KEY = 1;
   DDRD.2 = 1;
   PORTD.2 = 0;
   ADCSRA |= 0x80;  //startADC
   TCCR2 |= 0x02;   //start Timer2
}


// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
   GICR &= (~0x40);   //disable INT0
}


// initialization of INT0
void initInt0(void)
{
   // External Interrupt(s) initialization
   // INT0: On
   // INT0 Mode: Low level
   GICR|=0x40;
   MCUCR &= 0xFC;
   GIFR=0x40;
}


// Timer 2 overflow interrupt service routine
// multiplexing of LEDs
interrupt [TIM2_OVF] void timer2_ovf_isr(void)
{
   static unsigned char count = 0;
   static unsigned char framecount = 0;
   static unsigned int blinkcounter = 0;
   static bit bBlinkOn = 1;
   bit bLed;
   unsigned char state, i, value1, value2, value3;
   unsigned char *pState;
   
   blinkcounter++;
   if(blinkcounter == 1000)
   {
      bBlinkOn = ~bBlinkOn;
      blinkcounter = 0;
   }
   
   count++;
   if(count >= 12)
   {
      count = 0;
      P_DATA = 0;
      framecount++;
   }
   else
   {
      P_DATA = 1;
   }
   P_CLK = 1;
   P_CLK = 0;
   
   pState = &ledState[count*HEIGHT];
   
   value1 = 0;
   for(i = 0; i < 4; i++)
   {
      value1 >>= 1;
      state = (*pState) & (~BLINKING);
      bLed = 0;
      if(state == FIELD_PLAYER1)
      {
         bLed = 1;
      }
      else if(state == FIELD_PLAYER2)
      {
         if((framecount & 0x07) == 0x07)
            bLed = 1;
      }
      if((*pState) & BLINKING)
      {
         if(!bBlinkOn)
            bLed = 0;
      }
      if(bLed)
      {
         value1 |= 0x08;
      }
      pState++;
   }

   value2 = 0;
   for(i = 0; i < 4; i++)
   {
      value2 >>= 1;
      state = (*pState) & (~BLINKING);
      bLed = 0;
      if(state == FIELD_PLAYER1)
      {
         bLed = 1;
      }
      else if(state == FIELD_PLAYER2)
      {
         if((framecount & 0x07) == 0x07)
            bLed = 1;
      }
      if((*pState) & BLINKING)
      {
         if(!bBlinkOn)
            bLed = 0;
      }
      if(bLed)
      {
         value2 |= 0x80;
      }
      pState++;
   }

   value3 = 0;
   for(i = 0; i < 2; i++)
   {
      value3 >>= 1;
      state = (*pState) & (~BLINKING);
      bLed = 0;
      if(state == FIELD_PLAYER1)
      {
         bLed = 1;
      }
      else if(state == FIELD_PLAYER2)
      {
         if((framecount & 0x07) == 0x07)
            bLed = 1;
      }
      if((*pState) & BLINKING)
      {
         if(!bBlinkOn)
            bLed = 0;
      }
      if(bLed)
      {
         value3 |= 0x02;
      }
      pState++;
   }
   
   PORTC &= (~0x0F);
   PORTD &= (~0xF0);
   PORTB &= (~0x03);
   P_STROBE = 1;
   P_STROBE = 0;
   PORTC |= (value1);
   PORTD |= (value2);
   PORTB |= (value3);
   
}


// initialization of Timer2
void initTimer2(void)
{
// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: 1000,000 kHz
// Mode: Normal top=FFh
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x02;
TCNT2=0x00;
OCR2=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x40;
}


// initialization of ports
void init(void)
{
PORTB = 0;
DDRB = 0x1F;
PORTC = 0;
DDRC = 0x0F;
PORTD = 0;
DDRD = 0xF4;
PULLUP_KEY = 1;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;
}



// insert coin in column x and check for winner
// x: column position (0..WIDTH)
// player: player number (FIELD_PLAYER1 or FIELD_PLAYER2)
// return: 0=no winner yet, 1=current player has won
unsigned char insertCoinAndCheck(unsigned char x, unsigned char player)
{
   unsigned char led, y, count, startx, starty;
   unsigned char result = 0;
   signed char i, j;

   // calculate y position
   led = x * HEIGHT;
   ledState[led] = FIELD_FREE;
   for(y = 0; y < HEIGHT; y++)
   {
      if(ledState[led+y] != FIELD_FREE)
      {
         break;
      }
   }
   y--;
   
   //show animation with coin falling down in selected column
   for(i = 0; i < y; i++)   
   {
      ledState[led+i] = player;
      delay_ms(40);
      ledState[led+i] = FIELD_FREE;
   }   
   
   // activate field where coin is placed
   ledState[led+y] = player;

   //check for winning horizontal direction
   i = x;
   do
   {
      if( (ledState[i * HEIGHT + y] & (~BLINKING)) != player)
      {
         break;
      }
      i--;
   }
   while(i >= 0);
   i++;

   count = 0;
   startx = i;
   do
   {
      if( (ledState[i * HEIGHT + y] & (~BLINKING)) != player)
      {
         break;
      }
      count++;
      i++;
   }
   while(i < WIDTH);
   if(count >= 4)
   {
      result = 1;
      for(i = startx; i < (startx + count); i++)
      {
         ledState[i * HEIGHT + y] |= BLINKING;
      }
   }
   //end of check for winning horizontal direction


   //check for winning vertical direction
   count = 0;
   i = y;
   starty = i;
   do
   {
      if( (ledState[x * HEIGHT + i] & (~BLINKING)) != player)
      {
         break;
      }
      count++;
      i++;
   }
   while(i < HEIGHT);
   if(count >= 4)
   {
      result = 1;
      for(i = starty; i < (starty + count); i++)
      {
         ledState[x * HEIGHT + i] |= BLINKING;
      }
   }
   //end of check for winning vertical direction


   //check for winning diagonal / direction
   i = x;
   j = y;
   do
   {
      if( (ledState[i * HEIGHT + j] & (~BLINKING)) != player)
      {
         break;
      }
      i--;
      j++;
   }
   while( (i >= 0) && (j < HEIGHT) );
   i++;
   j--;
   
   count = 0;
   startx = i;
   starty = j;
   do
   {
      if( (ledState[i * HEIGHT + j] & (~BLINKING)) != player)
      {
         break;
      }
      count++;
      i++;
      j--;
   }
   while( (i < WIDTH) && (j >= 0) );
   if(count >= 4)
   {
      result = 1;
      j = starty;
      for(i = startx; i < (startx + count); i++)
      {
         ledState[i * HEIGHT + j] |= BLINKING;
         j--;
      }
   }
   //end of check for winning diagonal / direction


   //check for winning diagonal \ direction
   i = x;
   j = y;
   do
   {
      if( (ledState[i * HEIGHT + j] & (~BLINKING)) != player)
      {
         break;
      }
      i--;
      j--;
   }
   while( (i >= 0) && (j >= 0) );
   i++;
   j++;

   count = 0;
   startx = i;
   starty = j;
   do
   {
      if( (ledState[i * HEIGHT + j] & (~BLINKING)) != player)
      {
         break;
      }
      count++;
      i++;
      j++;
   }
   while( (i < WIDTH) && (j < HEIGHT) );
   if(count >= 4)
   {
      result = 1;
      j = starty;
      for(i = startx; i < (startx + count); i++)
      {
         ledState[i * HEIGHT + j] |= BLINKING;
         j++;
      }
   }
   //end of check for winning diagonal \ direction


   return(result);
}


#define ADC_VREF_TYPE 0x00

// initialization of ADC
void initADC(void)
{
   // ADC initialization
   // ADC Clock frequency: 125,000 kHz
   // ADC Voltage Reference: AREF pin
   ADMUX=ADC_VREF_TYPE & 0xff;
   ADCSRA=0x86;
}


// Read the AD conversion result
// adc_input: ADC channel (0..7)
// return: ADC value (0..1023)
unsigned int read_adc(unsigned char adc_input)
{
   ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
   // Delay needed for the stabilization of the ADC input voltage
   delay_us(10);
   // Start the AD conversion
   ADCSRA|=0x40;
   // Wait for the AD conversion to complete
   while ((ADCSRA & 0x10)==0);
   ADCSRA|=0x10;
   
   return ADCW;
}


// get selected field of current player
// player: player number (FIELD_PLAYER1 or FIELD_PLAYER2)
// return: selected field (0..WIDTH)
unsigned char getField(unsigned char player)
{
   unsigned char x;                        
   
   if(player == FIELD_PLAYER1)
   {
      x = (read_adc(6) / 86);
   }
   else
   {
      x = (WIDTH-1) - (read_adc(7) / 86);
   }
   
   return(x);
}


// main routine
void main(void)
{
   unsigned char i, result, player, x, selectedX;
   bit bNoWinner, bInc, bStartGame;

   init();
   initTimer2();
   initADC();
   initInt0();

   clearScreen();
   
   #asm("sei")      // Global enable interrupts

   bStartGame = 1;
   
   while(1)
   {
      if(bStartGame)
      {
         bStartGame = 0;
         showStartLogo();
         delay_ms(1000);
         clearScreen();
         do
         {
            x = getField(FIELD_PLAYER1);
            if(x < WIDTH/2)
            {
               player = FIELD_PLAYER1;
               showLogo(arrowLeftLogo, BLINKING);
            }
            else
            {
               player = FIELD_PLAYER2;
               showLogo(arrowRightLogo, BLINKING);
            }
         }
         while(!KEY_PRESSED);
         delay_ms(KEY_DEBOUNCE);
         while(KEY_PRESSED);
         delay_ms(KEY_DEBOUNCE);
         clearScreen();
      }
   
      x = getField(player);
      selectedX = x;

      bInc = 1;
      while( (ledState[selectedX*HEIGHT] & (~BLINKING)) != FIELD_FREE)
      {
         if(bInc)
         {
            if(selectedX < (WIDTH-1))
               selectedX++;
            else
               bInc = 0;
         }
         else
            selectedX--;
      }
      ledState[selectedX*HEIGHT] = player | BLINKING;
      
      do
      {
         x = getField(player);
      
         if((ledState[x*HEIGHT] & (~BLINKING)) == FIELD_FREE)
         {
            ledState[selectedX*HEIGHT] = FIELD_FREE;
            selectedX = x; 
            ledState[x*HEIGHT] = player | BLINKING;
         }
      }
      while(!KEY_PRESSED);
      delay_ms(KEY_DEBOUNCE);

      result = insertCoinAndCheck(selectedX, player);

      while(KEY_PRESSED);
      delay_ms(KEY_DEBOUNCE);
      
      bNoWinner = 1;
      for(i = 0; i < WIDTH; i++)
      {
         if(ledState[i*HEIGHT] == FIELD_FREE)
            bNoWinner = 0;
      }
      
      if( (result == 1) || bNoWinner )
      {
         if(bNoWinner)
         {
            for(i = 0; i < (WIDTH*HEIGHT); i++)
            {
               ledState[i] |= BLINKING;
            }
         }
         delay_ms(1000);         
         
         for(result = 200; result != 0; result--)
         {
            if(KEY_PRESSED)
               break;
            delay_ms(20);
         }           
         clearScreen();
         if(result == 0)
         {
            setStandbyMode();
         }
         delay_ms(KEY_DEBOUNCE);
         
         while(KEY_PRESSED);
         delay_ms(KEY_DEBOUNCE);
         bStartGame = 1;
      }
      else
      {
         if(player == FIELD_PLAYER1)
            player = FIELD_PLAYER2;
         else
            player = FIELD_PLAYER1;
      }
      
   }   
}
