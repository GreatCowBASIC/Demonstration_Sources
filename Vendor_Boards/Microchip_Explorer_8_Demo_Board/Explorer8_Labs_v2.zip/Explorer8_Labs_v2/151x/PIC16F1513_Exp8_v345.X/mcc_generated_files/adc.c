/**
  ADC Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    adc.c

  @Summary
    This is the generated driver implementation file for the ADC driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This source file provides implementations for driver APIs for ADC.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.65
        Device            :  PIC16F1513
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.45
        MPLAB             :  MPLAB X 4.10
*/
/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/
/**
  Section: Included Files
*/

#include <xc.h>
#include "adc.h"
#include "mcc.h"

/**
  Section: ADC Module APIs
*/

void ADC_Initialize(void)
{
    // set the ADC to the options selected in the User Interface
    
    // GO_nDONE stop; ADON enabled; CHS AN0; 
    ADCON0 = 0x01;
    
    // ADFM right; ADPREF VDD; ADCS FOSC/8; 
    ADCON1 = 0x90;
    
    // TRIGSEL no_auto_trigger; 
    AADCON2 = 0x00;
    
    // ADOEN No Connection; ADOOEN Not Overridden; ADDSEN Single conversion; ADOLEN No Connection; ADIPEN Non inverted; ADIPPOL VREF-; ADEPPOL Vss; 
    AADCON3 = 0x00;
    
    // ADSTG Not converting; ADCONV AADRES0H:AADRES0L; 
    AADSTAT = 0x00;
    
    // ADPRE 0; 
    AADPRE = 0x00;
    
    // ADACQ 0; 
    AADACQ = 0x00;
    
    // GRDBOE No Guard ring enabled; GRDAOE No Guard ring enabled; GRDPOL Low; 
    AADGRD = 0x00;
    
    // ADDCAP Additional uC disabled; 
    AADCAP = 0x00;
    
    // ADRES0L 0; 
    AADRES0L = 0x00;
    
    // ADRES0H 0; 
    AADRES0H = 0x00;
    
    // ADRES1L 0; 
    AADRES1L = 0x00;
    
    // ADRES1H 0; 
    AADRES1H = 0x00;
    
}

void ADC_SelectChannel(adc_channel_t channel)
{
    // select the A/D channel
    ADCON0bits.CHS = channel;    
    // Turn on the ADC module
    ADCON0bits.ADON = 1;  
}

void ADC_StartConversion()
{
    // Start the conversion
    ADCON0bits.GO_nDONE = 1;
}


bool ADC_IsConversionDone()
{
    // Start the conversion
   return ((bool)(!ADCON0bits.GO_nDONE));
}

adc_result_t ADC_GetConversionResult(void)
{
    // Conversion finished, return the result
	return ((adc_result_t)((AADRES0H << 8) + AADRES0L));
}

adc_result_t ADC_GetConversion(adc_channel_t channel)
{
    // select the A/D channel
    ADCON0bits.CHS = channel;    
    
    // Turn on the ADC module
    ADCON0bits.ADON = 1;

    // Start the conversion
    ADCON0bits.GO_nDONE = 1;

    // Wait for the conversion to finish
    while (ADCON0bits.GO_nDONE)
    {
        CLRWDT();
    }

    // Conversion finished, return the result
    return ((adc_result_t)((AADRES0H << 8) + AADRES0L));
}

void ADC_TemperatureAcquisitionDelay(void)
{
    __delay_us(200);
}

void ADC_EnableDoubleSampling(void)
{
    //Sets the AADCON3bits.ADDSEN
    AADCON3bits.ADDSEN = 1;
}

adc_sync_double_result_t ADC_GetDoubleConversionResult(void)
{
    adc_sync_double_result_t adcDoubleResult;

    // Conversion finished, read the result
    adcDoubleResult.adcResult1 = (uint16_t)((AADRES0H << 8) + AADRES0L);
    adcDoubleResult.adcResult2 = (uint16_t)((AADRES1H << 8) + AADRES1L);

    // return the result
    return adcDoubleResult;
}

uint8_t ADC_GetStageStatus(void)
{
	//Returns the contents of AADSTATbits.ADSTG field.
	return AADSTATbits.ADSTG;
}

uint8_t ADC_GetConversionStatus(void)
{
	//Returns the contents of AADSTATbits.ADCONV field.
	return AADSTATbits.ADCONV;
}

void ADC_SetPrechargeTime(uint8_t prechargeTime)
{
	//Load the AADPRE register.
	AADPRE = prechargeTime;  
}

void ADC_SetAcquisitionTime(uint8_t acquisitionValue)
{
	//Load the AADACQ register.
	AADACQ = acquisitionValue;   
}

/**
 End of File
*/