Release Notes for PICDEM 4(tm) Demo Board v1.00
Firmware v1.00
March 17, 2003

-----------------------------------------------------------------
Table of Contents
-----------------------------------------------------------------
1. Important Notes
2. Folder Contents
3. How to Contact Microchip
4. Customer Change Notification - Development Systems


------------------------------------------------------------
1. Important Notes
------------------------------------------------------------

MPLAB ICD SPECIFIC LINKER FILE

MPLAB IDE provides a separate linker script file that reserves the 
resources used by the MPLAB ICD and MPLAB ICD 2; such files include 
an 'i' in the name of the file (for example, 16f877i.lkr).
Customers that are using the MPLAB ICD should use this file instead of the 
standard linker files.


----------------------------------------------------------------------
2. CD-ROM Contents
----------------------------------------------------------------------

The contents of the PICDEM_4 folder on this CD-ROM are as follows:

*** Application Notes


***pic16
  	PICDEM 4 16F Demo- this folder contains all of the files for the PIC16 demo.

***pic18
	PICDEM 4 18F Demo- this folder contains all of the files for the PIC18 demo.

***Supercapacitor
	This folder contains all of the files needed to demonstrate low power
	capabilities. 

***UserGuide
  	51337A.pdf - PICDEM 4 Demo Board User's Guide

----------------------------------------------------------------------
3. How to Contact Microchip
----------------------------------------------------------------------

Online Support
---------------
Microchip provides online support on the Microchip World Wide Web (WWW)
site. The web site is used by Microchip as a means to make files and
information easily available to customers. To view the site, you must
have access to the Internet and a web browser such as Netscape or
Microsoft Explorer. Files are also available for FTP download from
our FTP site.

Connecting to the Microchip Internet Web Site
---------------------------------------------
The Microchip web site is available by using your favorite Internet
browser to attach to:

        http://www.microchip.com


The web site provides a variety of services.
Users may download files for the latest development tools,
data sheets, application notes, User's guides, articles, and sample
programs. A variety information specific to the business of Microchip
is also available, including listings of Microchip sales offices,
distributors and factory representatives.

Other data available for consideration is:

        * Latest Microchip Press Releases

        * Technical Support Section with Frequently Asked
          Questions

        * Design Tips

        * Device Errata

        * Job Postings

        * Microchip Consultant Program Member Listing

        * Links to other useful web sites related to
          Microchip products

        * Conferences for products, Development Systems,
          technical information and more

        * Listing of seminars and events

Systems Information and Upgrade Hotline
----------------------------------------
The Systems Information and Upgrade Line provides system users with a listing
of the latest versions of all of Microchip's development systems, software
products, and information on how customers can receive any currently
available upgrade kits. The Hot Line Numbers are:

        1-800-755-2345 for U.S. and most of Canada, and

        1-480-792-7302 for the rest of the world.

----------------------------------------------------------------------
4. Customer Change Notification - Development Systems
----------------------------------------------------------------------

Microchip started the customer notification service to help our
customers keep current on Microchip products with the least amount
of effort. Once you subscribe, you will receive email notification
whenever we change, update, revise or have errata related to your
specified product family or development tool of interest.

Go to the Microchip WWW web page (http://www.microchip.com)
and click on Customer Change Notification under Items of Interest.
Follow the instructions to register.

The Development Systems product group categories are:

* Compilers
* Emulators
* In-Circuit Debuggers
* MPLAB
* Programmers

Here is a description of these categories:

COMPILERS - The latest information on Microchip C compilers, linkers
and assemblers.  These include MPLAB C17 C compiler, MPLAB C18
C compiler, MPLINK object linker (as well as the MPLIB object
librarian) and MPASM assembler.

EMULATORS - The latest information on Microchip in-circuit emulators.
These include the MPLAB ICE 2000 and MPLAB ICE 4000.

IN-CIRCUIT DEBUGGERS - The latest information on Microchip in-circuit
debuggers. These include the MPLAB ICD and MPLAB ICD 2.

MPLAB - The latest information on Microchip MPLAB IDE, the Windows
Integrated Development Environment for development systems tools.
This list is focused on the MPLAB IDE, MPLAB SIM simulator,
MPLAB IDE Project Manager and general editing and debugging features.

PROGRAMMERS - The latest information on Microchip PICmicro device
programmers. These include the PRO MATE II device programmer and
PICSTART Plus development programmer.
