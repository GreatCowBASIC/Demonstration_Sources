/********************************************************************
*
*                
*
*********************************************************************
* FileName:        Main.c
* Dependencies:    See INCLUDES section below
* Processor:       PIC16F1937
* Compiler:        HTC
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description: Main module with the main() function. It includes
*                   the application code with the main state machine
*                   controlling the application's behavior.
*
* Change History:
* Author               Date        Comment
* Lyes Garidi          10/18/2010  First version of code
********************************************************************/

//*****************************************************************************
// Include and Header files
//*****************************************************************************

#include <p18cxxx.h>
#include <p18f46k22.h>
#include <GenericTypeDefs.h>
#include "I2c.h"
#include "Lcd.h"
#include "General.h"

///////////////////////////////////////////////////////////////////////////////
//*****************************************************************************
// MACROS
//*****************************************************************************
///////////////////////////////////////////////////////////////////////////////

/***************************** MACROS CONSTANTS ************************************/


/***************************** LABEL MACROS ****************************************/

#define MICROCHIP()		LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('M');	\
					  	LCDPutChar('i');	\
					  	LCDPutChar('c');	\
					  	LCDPutChar('r');	\
					  	LCDPutChar('o');	\
					  	LCDPutChar('c');	\
					  	LCDPutChar('h');	\
					  	LCDPutChar('i');	\
					  	LCDPutChar('p');	\
					  	LCDGoto(0,1);		\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('P');	\
					  	LCDPutChar('I');	\
					  	LCDPutChar('C');	\
					  	LCDPutChar('D');	\
					  	LCDPutChar('E');	\
					  	LCDPutChar('M');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('2');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('P');	\
					  	LCDPutChar('L');	\
					  	LCDPutChar('U');	\
					  	LCDPutChar('S');

#define	VOLTMETER()  	LCDGoto(0,0);       \
						LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('V');	\
					  	LCDPutChar('o');	\
					  	LCDPutChar('l');	\
					  	LCDPutChar('t');	\
					  	LCDPutChar('m');	\
					  	LCDPutChar('e');	\
					  	LCDPutChar('t');	\
						LCDPutChar('e');	\
					  	LCDPutChar('r');

#define BUZZER()  		LCDGoto(0,0);    	\
						LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('B');	\
					  	LCDPutChar('u');	\
					  	LCDPutChar('z');	\
					  	LCDPutChar('z');	\
					  	LCDPutChar('e');	\
					  	LCDPutChar('r');

#define TEMPERATURE()	LCDGoto(0,0);       \
						LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('T');	\
					  	LCDPutChar('e');	\
					  	LCDPutChar('m');	\
					  	LCDPutChar('p');	\
					  	LCDPutChar('e');	\
					  	LCDPutChar('r');	\
					  	LCDPutChar('a');	\
					  	LCDPutChar('t');	\
					  	LCDPutChar('u');	\
					  	LCDPutChar('r');	\
					  	LCDPutChar('e');

#define CLOCK()			LCDGoto(0,0);     	\
						LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar(' ');	\
					  	LCDPutChar('C');	\
					  	LCDPutChar('l');	\
					  	LCDPutChar('o');	\
					  	LCDPutChar('c');	\
					  	LCDPutChar('k');

/***************************** VALUE MACROS ****************************************/

#define VOLTAGE()	  	LCDGoto(0,0);						\
					  	LCDPutChar('V');					\
					  	LCDPutChar('o');					\
					  	LCDPutChar('l');					\
					  	LCDPutChar('t');					\
					  	LCDPutChar('s');					\
					 	LCDPutChar(' ');					\
					  	LCDPutChar('=');					\
					  	LCDPutChar(' ');					\
					 	LCDPutChar(Volt/100+'0');			\
					 	LCDPutChar('.');					\
					  	LCDPutChar((Volt / 10)%10+'0');		\
					  	LCDPutChar((Volt /1)% 10+'0');		\
					  	LCDPutChar('V');					\
					  	LCDPutChar(' ');					\
					  	LCDPutChar(' ');					\
					  	LCDPutChar(' ');					\
					  	LCDPutChar(' ');

#define DUTYCYCLE()		LCDGoto(0,0);												\
					  	LCDPutChar('D');											\
					  	LCDPutChar('u');											\
					  	LCDPutChar('t');											\
					  	LCDPutChar('y');											\
					  	LCDPutChar(' ');											\
					  	LCDPutChar('C');											\
					  	LCDPutChar('y');											\
					  	LCDPutChar('c');											\
					  	LCDPutChar('l');											\
					  	LCDPutChar('e');											\
					  	LCDPutChar(' ');											\
					  	LCDPutChar('=');											\
					  	LCDPutChar(((((PWM_Period/5)-1)*2) / 100) + '0');			\
					  	LCDPutChar(((((((PWM_Period/5)-1)*2) /10)/1) % 10) + '0');	\
					  	LCDPutChar(((((PWM_Period/5)-1)*2) % 10) + '0');			\
					  	LCDPutChar('%');

#define TEMPREADING()	LCDGoto(0,0);							\
					  	LCDPutChar('T');						\
					  	LCDPutChar('e');						\
					  	LCDPutChar('m');						\
					  	LCDPutChar('p');						\
					  	LCDPutChar(' ');						\
					  	LCDPutChar('=');						\
					  	LCDPutChar(' ');						\
					 	if (negValue == 1)						\
						{	LCDPutChar('-');	}				\
						else									\
						{	LCDPutChar(Thermal/100+'0');	}	\
					  	LCDPutChar(Thermal/10+'0');				\
					  	LCDPutChar(Thermal % 10+'0');			\
					  	LCDPutChar(223);						\
					  	LCDPutChar('C');						\
					  	LCDPutChar(' ');						\
					  	LCDPutChar(' ');						\
					  	LCDPutChar(' ');						\
					  	LCDPutChar(' ');						\
					  	LCDPutChar(' ');
// Character [223] creates the degree symbol
					  
#define SHOWTIME()		LCDGoto(0,0);				\
					  	LCDPutChar('T');			\
					  	LCDPutChar('I');			\
					  	LCDPutChar('M');			\
					  	LCDPutChar('E');			\
					  	LCDPutChar(' ');			\
					  	LCDPutChar(' ');			\
					  	LCDPutByte(dateTime.Hour);	\
					  	LCDPutChar(':');			\
					  	LCDPutByte(dateTime.Min);	\
					  	LCDPutChar(':');			\
					  	LCDPutByte(dateTime.Sec);

/***************************** MENU MACROS *****************************************/

#define BIGMENU()	  	LCDGoto(0,1);			\
						LCDPutChar('R');		\
					  	LCDPutChar('A');		\
					  	LCDPutChar('4');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar('N');		\
					  	LCDPutChar('e');		\
					  	LCDPutChar('x');		\
					  	LCDPutChar('t');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar('R');		\
					  	LCDPutChar('B');		\
					  	LCDPutChar('0');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar('N');		\
					  	LCDPutChar('o');		\
					  	LCDPutChar('w');

#define SMALLMENU()	  	LCDGoto(0,1);			\
						LCDPutChar(' ');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar('R');		\
					  	LCDPutChar('B');		\
					  	LCDPutChar('0');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar('E');		\
					  	LCDPutChar('x');		\
					  	LCDPutChar('i');		\
					  	LCDPutChar('t');

#define BUZZMENU()	  	LCDGoto(0,1);			\
						LCDPutChar('R');		\
					  	LCDPutChar('A');		\
					  	LCDPutChar('4');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar('+');		\
					  	LCDPutChar('2');		\
					  	LCDPutChar('%');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar('R');		\
					  	LCDPutChar('B');		\
					  	LCDPutChar('0');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar('E');		\
					  	LCDPutChar('x');		\
					  	LCDPutChar('i');		\
					  	LCDPutChar('t');

#define CLOCKSET()  	LCDGoto(0,1);			\
						LCDPutChar('R');		\
					  	LCDPutChar('A');		\
					  	LCDPutChar('4');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar('S');		\
					  	LCDPutChar('e');		\
					  	LCDPutChar('t');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar(' ');		\
					  	LCDPutChar('R');		\
					  	LCDPutChar('B');		\
					  	LCDPutChar('0');		\
					  	LCDPutChar('=');		\
					  	LCDPutChar('N');		\
					  	LCDPutChar('o');		\
					  	LCDPutChar('w');

/***************************** SERIAL MACROS **********************************/


#define SERIALVOLTS()	if (Volt != prevVolt)					\
						{										\
							  	SERTxSave(CR);            		\
								SERTxSave(LF);                  \
								SERTxSave('V');					\
							  	SERTxSave('o');					\
							  	SERTxSave('l');					\
							  	SERTxSave('t');					\
							  	SERTxSave('s');					\
								SERTxSave(' ');					\
							  	SERTxSave('=');					\
							  	SERTxSave(' ');					\
							  	SERTxSave(Volt/100+'0');		\
							  	SERTxSave('.');					\
							  	SERTxSave((Volt / 10)%10+'0');	\
							  	SERTxSave((Volt /1)% 10+'0');	\
							  	SERTxSave('V');					\
							  	SERTxSave(' ');					\
							  	SERTxSave(' ');					\
							  	SERTxSave(' ');					\
							 	SERTxSave(' ');					\
						}
// If Voltage Data has Changed
// Carriage return
// Line Feed

#define SERIALTEMP()		SERTxSave(LF);                  \
						  	SERTxSave(CR);                  \
						  	SERTxSave('T');					\
						  	SERTxSave('e');					\
						  	SERTxSave('m');					\
						  	SERTxSave('p');					\
						  	SERTxSave(' ');					\
						  	SERTxSave('=');					\
						  	SERTxSave(' ');					\
						 	if (negValue == 1)				\
							{								\
						  		SERTxSave('-');             \
							}								\
							else							\
							{								\
						  		SERTxSave(Thermal/100+'0'); \
							}								\
						  	SERTxSave(Thermal/10+'0');      \
						  	SERTxSave(Thermal % 10+'0');    \
						  	SERTxSave(248);                 \
						  	SERTxSave('C');					\
						  	SERTxSave(' ');					\
						  	SERTxSave(' ');					\
						  	SERTxSave(' ');					\
						  	SERTxSave(' ');					\
						  	SERTxSave(' ');

#define	SERIALTIME()		if (timeHasChgd)							\
							{											\
						  		SERTxSave(CR);                          \
						  		SERTxSave(LF);                          \
						  		SERTxSave(dateTime.Hour/10+'0');		\
						  		SERTxSave(dateTime.Hour % 10+'0');		\
						  		SERTxSave(':');							\
						  		SERTxSave(dateTime.Min/10+'0');			\
						  		SERTxSave(dateTime.Min % 10+'0');		\
						  		SERTxSave(':');							\
						  		SERTxSave(dateTime.Sec/10+'0');			\
						  		SERTxSave(dateTime.Sec % 10+'0');		\
								timeHasChgd = FALSE;					\
							}											

//*****************************************************************************
//Local Function Prototypes
//*****************************************************************************

void DisplaySplashText(void);
void DisplayVoltMenu(void);
void DisplayVoltage(UINT16 Volt);
void DisplayBuzMenu(void);
void DisplayBuzzerData(UINT8 PWM_Period);
void DisplayTempMenu(void);
void DisplayTemperature(UINT8 Thermal);
void DisplayClockMenu(void);
void DisplayTime(void);
void Set_Time(void);

///////////////////////////////////////////////////////////////////////////////
//*****************************************************************************
// SUPPORT FUNCTIONS
//*****************************************************************************
///////////////////////////////////////////////////////////////////////////////

/******************************************************************************
* Function:          DisplaySplashText
*
* PreCondition: 	None
*
* Input:        	None
*
* Output:     		None
*
* Side Effects: 	None
*
* Overview:         This function is called to display the splash screen when the
*                   app resets.
*
* Note:        		None
******************************************************************************/

void DisplaySplashText(void)
{
  	LCDClear();
	MICROCHIP();
}

/******************************************************************************
* Function: void DisplayVoltMenu(void)
*
* Overview: This function is called to display the Voltmeter selection screen.
*
* Input:    None
*
* Output:   None
*
******************************************************************************/

void DisplayVoltMenu(void)
{
	VOLTMETER();
	BIGMENU();
}

/******************************************************************************
* Function: void DisplayVoltMenu(void)
*
* Overview: This function is called to display current voltage on the
*           potentiometer. It gets the raw A/D reading and converts it into a
*           real voltage data before displaying it.
*
* Input:    Raw converted value.
*
* Output:   None
*
* NB: If the serial transmission is enabled, and the data has changed, the
      displayed value is also sent on the serial line.
******************************************************************************/

void DisplayVoltage(UINT16 Volt)
{
 	static UINT16 prevVolt;						// Buffer for previous voltage value
  	Volt = ((Volt*VOLTAGE_CHANGE)/10)/10;

	VOLTAGE();
	SMALLMENU();

#ifdef SERIAL_COM
	SERIALVOLTS();
#endif
}

/******************************************************************************
* Function: void DisplayBuzMenu(void)
*
* Overview: This function is called to display the Buzzer selection screen.
*
* Input:    None
*
* Output:   None
*
******************************************************************************/

void DisplayBuzMenu(void)
{
	BUZZER();
	BIGMENU();
}

/******************************************************************************
* Function: void DisplayBuzzerData(void)
*
* Overview: This function is called to display current Buzzer settings. 
*
* Input:    None
*
* Output:   None
*
******************************************************************************/

void DisplayBuzzerData(UINT8 PWM_Period)
{
	DUTYCYCLE();
	BUZZMENU();
}

/******************************************************************************
* Function: void DisplayTempMenu(void)
*
* Overview: This function is called to display the Temperature selection screen
*
* Input:    None
*
* Output:   None
*
******************************************************************************/

void DisplayTempMenu(void)
{
	TEMPERATURE();
	BIGMENU();
}

/******************************************************************************
* Function: void DisplayTemperature(unsigned char Thermal)
*
* Overview: This function is called to display the current temperature reading
*           from the probe on the board. It take the specified raw reading from
            converts it into ASCII before displaying it.
*
* Input:    Temperature reading.
*
* Output:   None
*
* NB: If the serial transmission is enabled, and the data has changed, the
      displayed value is also sent on the serial line.
******************************************************************************/

void DisplayTemperature(UINT8 Thermal)
{
	UINT8 negValue;
	static UINT16 prevTherm;

	if (Thermal >= 128)
	{ 
		Thermal = 256 - Thermal;
		negValue = 1;
	}
	else
	{
		Thermal = Thermal;
		negValue = 0;
	}
	
	TEMPREADING();
	SMALLMENU();

#ifdef SERIAL_COM
	SERIALTEMP();
#endif
}

/******************************************************************************
* Function: void DisplayClockMenu(void)
*
* Overview: This function is called to display the Clock selection screen
*
* Input:    None
*
* Output:   None
*
******************************************************************************/

void DisplayClockMenu(void)
{
	CLOCK();
	BIGMENU();
}

/******************************************************************************
* Function: void DisplayTime(void)
*
* Overview: This function is called after the user has confirmed the "Clock"
            mode to display current system time. The user is offered the
            possibility to set the time using the RA4 button.
*
* Input:    None.
*
* Output:   None
*
* NB: If the serial transmission is enabled, and the time has changed, the
      new time value is also sent on the serial line.
******************************************************************************/

void DisplayTime(void)
{
	SHOWTIME();
	CLOCKSET();

#ifdef SERIAL_COM									// If Data transmission enabled
	SERIALTIME();
#endif
}

/******************************************************************************
* Function: void Set_Time(void)
*
* Overview: 
*
* Input:    None.
*
* Output:   None
*
* NB: If the serial transmission is enabled, and the time has changed, the
      new time value is also sent on the serial line.
******************************************************************************/

void Set_Time(void)
{
  LCDGoto(0,0);

  LCDPutByte(dateTime.Hour);
  LCDPutChar(':');
  LCDPutByte(dateTime.Min);
  LCDPutChar(':');
  LCDPutByte(dateTime.Sec);

  LCDGoto(0,1);

  LCDPutChar('R');
  LCDPutChar('A');
  LCDPutChar('4');
  LCDPutChar('=');
  LCDPutChar('+');
  LCDPutChar('R');
  LCDPutChar('B');
  LCDPutChar('0');
  LCDPutChar('=');
  LCDPutChar('-');
  LCDPutChar('B');
  LCDPutChar('o');
  LCDPutChar('t');
  LCDPutChar('h');
  LCDPutChar('-');
  LCDPutChar('>');

  SERTxSave(CR);                                              // Carriage return
  SERTxSave(LF);                                                    // Line Feed
  SERTxSave(dateTime.Hour/10+'0');
  SERTxSave(dateTime.Hour % 10+'0');
  SERTxSave(':');
  SERTxSave(dateTime.Min/10+'0');
  SERTxSave(dateTime.Min % 10+'0');
  SERTxSave(':');
  SERTxSave(dateTime.Sec/10+'0');
  SERTxSave(dateTime.Sec % 10+'0');
}
