/********************************************************************
*
*                
*
*********************************************************************
* FileName:        Sound.h
* Dependencies:    See INCLUDES section below
* Processor:       PIC16F1937
* Compiler:        HTC
* Company:         Microchip Technology, Inc.
*
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
* File Description:
*
* Change History:
* Author               Date        Comment
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Lyes Garidi          10/19/2010  First revision of code
********************************************************************/

/**
*   @file Sound.h
*   @brief 	This file contains the function prototypes for the Sound
*			or  Buzzer functions used within the program.
*   
*/

#ifndef _SOUND
#define _SOUND

#include "General.h"

void SNDInit(void);									///< Initialize the CCP/PWM to use with buzzer.
void SNDSound(UINT8_T OnOff, UINT8_T PWM_Period);		///< Send sound information to buzzer to generate sound.

#endif
