/** @file doc.h
* @brief Used to generate this documentation. Safe to delete.
*/
/**
* @mainpage
*
* @warning <i>This is a <b>development release</b> of the PICDEM 2 PLUS.</i>
*
* @section Support Support Information
* @subpage GettingStarted<br>
* @subpage SoftwareLicense<br>
* @subpage PICSupport<br>
*
* @section SM State Machine
* @subpage StateMachine<br>
* <hr>
* @section Introduction
* The application demonstrates how to use the different capabilities
* of the new PicDem 2 Plus board. The user has the possibility to get
* an ambient temperature reading from the TC74 probe, use the
* potentiometer to display different voltage readings, activate and
* adjust the buzzer sound, display and set the system time managed by
* the embedded Real Time Clock, and more.<br> <br>
* The easy to follow code included with the PICDEM 2 PLUS will help
* students to learn the functions and special parephials included with
* the powerful PIC devices developed by Microchip. The demo board includes
* the capability to test 18, 28 and 40 pin devices. Include are two pre-programmed
* 40 pin devices which use the powerful Hi-Tech (PIC16F1937) and C-18 (PIC18F45K22)
* compilers. 
* <br>
* <br><b>The included demo program will teach the user how to use: </b>
* <ul> 
* <li>Analog-to-Digital Module [ADC]</li>
* <li> Capture/Compare/Pulse Width Module [CCP]</li>
* <li>Master Synchronous Serial Port Module [MSSP] </li> 
* <li> Highlight the use of Inner-Integrated Circuit [I2C] for 2 [SDA, SCL] communication </li>
* <li> Drive a 7 pin LCD display </li>
* <li> Use of multiple timers [Timer0, Timer1, Timer4] </li>
* <li> Create a real time counter by using a dedicated external 32kHz crystal </li>
* <li> Communicate over a Enhanced Universal Synchronous Asynchronous Receiver Transmitter [EUSART] through the use
* of a RS232 connector and Windows HyperTerminal program. </li>
* </ul>
* <br>
* By working with the included program the user will learn how to create a project from multiple .C & .H files. 
* <hr>
* @section Features Picdem 2 Plus Demo Board Features
* <p><ul>
* <li> Supports 18, 28 and 40 pin devices </li>
* <li> Supports 9V External Power Supply, 9V External Battery, Power through PICKIT USB </li>
* <li> Programmable Via PICKIT or ICD </li>
* <li> Easily re-configured jumper support for a wider range of functionality </li> 
* </ul></p>
* @subsection OnBoard On-Board Functions
* <ul><li> On-board LCD </li>
* <li> 3 simple buttons </li>
* <li> POT </li>
* <li> Speaker </li>
* <li> TC74 Temperature sensor </li>
* <li> 32 kHz crystal </li>
* <li> 4 LED's </li>
* <li> Generous Prototype space </li>
* <li> Expansion slots for [2] additional External Crystals
* <li> Expansion slot for a EEPROM device </li> </ul>
*
* @subsection FunUsed Functions Used
* <ul> 
* <li> [ADC] Analog-to-Digital used in Voltmeter.c </li>
* <li> [PWM] Pulse Width Module used in Sound.c </li>
* <li> [I2C] Inner-Integrated Circuit used in I2C.c </li>
* <li> [32kHz External Crystal] Timer1 used in RTC.c </li>
* <li> [EUSART] Enhanced Universal Synchronous Asynchronous Receiver Transmitter used in Serial.c </li>
* <li> [LCD] Use of PORTD to drive LCD used in LCD.c </li>
* <li> [Buttons] Simple Button detection and debouncing used in Buttons.c
* </ul>
*
*/
/**
* @page PICSupport Supported PIC&reg; Microcontrollers
*
* @section PICDevices Enhanced Core Mid-Range Devices
* @li <b>PIC16 Microcontrollers</b>
* <ul>
* <li>PIC16F/LF1937 :: 40 Pin Device
* <li>PIC16F/LFXXXX :: 28 Pin Device
* <li>PIC16F/LFXXXX :: 18 Pin Device
* </ul>
* @li <b>PIC18 Microcontrollers</b>
* <ul>
* <li>PIC18F/LF46K22 :: 40 Pin Device
* <li>PIC18F/LFXXXX :: 28 Pin Device
* <li>PIC18F/LFXXXX :: 18 Pin Device
* </ul>
*/
/**
* @page GettingStarted Understanding Operation and Function of PICDEM 2 Board
* @section Psetup	Board Setup
* @subpage INTCB <br>
* @subpage BPSetup <br>
* @subpage PKSARS232 <br>
*<hr>
* @section P2setup	Operation
* @subpage StartUp <br>
* @subpage Voltmeter  <br>
* @subpage Buzzer  <br>
* @subpage Temperature  <br>
* @subpage Clock <br>
*/
/**
* @page INTCB Configuration Bits Setup
* @section ConfigBits	PIC Configuration Word Registers [PIC16F1937]
* @subsection CW1 Config Word 1
*<br><b>FOSC_INTOSC:</b> High speed internal oscillator
*<br><b>WDTE_OFF:</b> Watchdog timer disabled
*<br><b>PWRTE_OFF:</b> Power-up Timer disabled
*<br><b>MCLRE_ON:</b> Master Clear Function enabled 
*<br><b>CP_OFF:</b> Code Protector disabled
*<br><b>CPD_OFF:</b> Date EE read disabled
*<br><b>BOREN_OFF:</b> Brown-out Reset disabled
*<br><b>CLKOUTEN_ON:</b> Clock out on RA7 disabled
*<br><b>IESO_OFF:</b> Internal External clock switch disabled
*<br><b>FCMEN_OFF:</b> Fail clock monitor disabled
*
* @subsection CW2 Config Word 2
*<br><b>WRT_OFF:</b> High speed internal oscillator
*<br><b>VCAPEN_OFF:</b> Watchdog timer disabled
*<br><b>PLLEN_OFF:</b> Power-up Timer disabled
*<br><b>STVREN_OFF:</b> Master Clear Function enabled 
*<br><b>BORV_25:</b> Code Protector disabled
*<br><b>CPD_OFF:</b> Date EE read disabled
*<br><b>LVP_OFF:</b> Brown-out Reset disabled
*
* @subpage P16CWList	
* <hr>
* @section ConfigBits18	PIC Configuration Word Registers [PIC18F46K22]
* @subsection CW18	CONFIG WORD
* <br><b> FOSC = INTIO67   </b>:Internal OSC block, Port Function on RA6/7
* <br><b> PLLCFG = OFF   </b>:OSC used Directly; PLL -Disabled
* <br><b> PRICLKEN = OFF   </b>:Primary clock can be disabled by software
* <br><b> FCMEN = ON     </b>:Fail-Safe Clock Monitor disabled
* <br><b> IESO = OFF     </b>:OSC switch mode disabled
* <br><b> PWRTEN = OFF   </b>:Power Up Timer is disabled
* <br><b> BOREN = OFF    </b>:Brown-out Reset disabled in Hardware and Soft
* <br><b> BORV = 250     </b>:VBOR set to 2.50 V nominal
* <br><b> WDTEN = OFF    </b>:Watch Dog Timer disabled. SWDTEN no effect
* <br><b> WDTPS = 1      </b>:Watch Dog Timer Postscale 1:1
* <br><b> CCP2MX = PORTC1   </b>:CCP2 input/output is multiplexed with RC1
* <br><b> PBADEN = OFF   </b>:PORTB<5:0> pins are Config as Digital I/O on Reset
* <br><b> CCP3MX = PORTE0   </b>:P3A/CCP3 input/output is multiplexed with RE0
* <br><b> HFOFST = OFF   </b>:HFINTOSC ouput and ready status are delayed by OSC stable status
* <br><b> T3CMX = PORTB5   </b>:T3CKl is on RB5
* <br><b> P2BMX = PORTC0   </b>:P2B is on RC0
* <br><b> MCLRE = EXTMCLR   </b>:MCLR pin enabled, RE3 input pin disabled
* <br><b> STVREN = OFF   </b>:  Stack full/underflow will not cause Reset
* <br><b> LVP = OFF      </b>:  Single-Supply ICSP disabled
* <br><b> XINST = OFF    </b>:  Instruction set Extension and indexed Addressing mode disabled
* <br><b> DEBUG = OFF    </b>:  Disabled
*
* <br><b> CP0 = OFF      </b>:  Block 0 (000800 - 001FFFh) not code-protected
* <br><b> CP1 = OFF      </b>:  Block 1 (002000 - 003FFFh) not code-protected
* <br><b> CP2 = OFF      </b>:  Block 2 (004000 - 005FFFh) not code-protected
* <br><b> CP3 = OFF      </b>:  Block 3 (006000 - 007FFFh) not code-protected
* <br><b> CPB = OFF      </b>:  Boot Block (000000 - 0007FFh) not code-protected
* <br><b> CPD = OFF      </b>:  Data EEPROM not code-protected
*
* <br><b> WRT0 = OFF     </b>:  Block 0 (000800-001FFFh) not write-protected
* <br><b> WRT1 = OFF     </b>:  Block 1 (002000-003FFFh) not write-protected
* <br><b> WRT2 = OFF     </b>:  Block 2 (004000-005FFFh) not write-protected
* <br><b> WRT3 = OFF     </b>:  Block 3 (006000-007FFFh) not write-protected
* <br><b> WRTC = OFF     </b>:  Configuration registers (300000-3000FFh) not write protected
* <br><b> WRTB = OFF     </b>:  Boot Block (000000-0007FFh) not write-protected
* <br><b> WRTD = OFF     </b>:  Data EEPROM not write-protected
*
* <br><b> EBTR0 = OFF    </b>:  Block 0 (000800 - 001FFFh) not protected from table reads executed in other blocks
* <br><b> EBTR1 = OFF    </b>:  Block 0 (002000 - 003FFFh) not protected from table reads executed in other blocks
* <br><b> EBTR2 = OFF    </b>:  Block 0 (004000 - 005FFFh) not protected from table reads executed in other blocks
* <br><b> EBTR3 = OFF    </b>:  Block 0 (006000 - 007FFFh) not protected from table reads executed in other blocks
* <br><b> EBTRB = OFF    </b>:  Block 0 (000000 - 0007FFh) not protected from table reads executed in other blocks
*
* @subpage P18CWList
*/
/**
* @page P16CWList PIC16F1937 Configuration Word Options
*
*<br> @section CR Config Register: CONFIG1
*<hr>
*@subsection OSC Oscillator Selection
*<br><b> FOSC_ECH:</b> ECH, External Clock, High Power Mode (4-32 MHz): device clock supplied to CLKIN pin             
*<br><b> FOSC_ECM: </b> ECM, External Clock, Medium Power Mode (0.5-4 MHz): device clock supplied to CLKIN pin    
*<br><b> FOSC_ECL: </b> ECL, External Clock, Low Power Mode (0-0.5 MHz): device clock supplied to CLKIN pin
*<br><b> FOSC_INTOSC: </b> INTOSC oscillator: I/O function on CLKIN pin
*<br><b> FOSC_EXTRC: </b> EXTRC oscillator: External RC circuit connected to CLKIN pin
*<br><b> FOSC_HS: </b> HS Oscillator, High-speed crystal/resonator connected between OSC1 and OSC2 pins
*<br><b> FOSC_XT: </b> XT Oscillator, Crystal/resonator connected between OSC1 and OSC2 pins
*<br><b> FOSC_LP: </b> LP Oscillator, Low-power crystal connected between OSC1 and OSC2 pins
*
*<hr>
*@subsection WDT Watchdog Timer
*<br><b> WDTE_ON: </b> WDT enabled
*<br><b> WDTE_NSLEEP: </b>WDT enabled while running and disabled in Sleep
*<br><b> WDTE_SWDTEN: </b>WDT controlled by the SWDTEN bit in the WDTCON register
*<br><b> WDTE_OFF: </b>WDT disabled
*
*<hr>
*@subsection PUT Power-up Timer Enable
*<br><b> PWRTE_OFF: </b>PWRT disabled
*<br><b> PWRTE_ON: </b>PWRT enabled
*
*<hr>
*@subsection MCLR MCLR Pin Function Select
*<br><b> MCLRE_ON: </b>MCLR/VPP pin function is MCLR
*<br><b> MCLRE_OFF: </b>MCLR/VPP pin function is digital input
*
*<hr>
*@subsection FPM Flash Program Memory Code Protection
*<br><b> CP_OFF: </b>Program memory code protection is disabled
*<br><b> CP_ON: </b> Program memory code protection is enabled
*
*<hr>
*@subsection DM Data Memory Code Protection
*<br><b> CPD_OFF: </b> Data memory code protection is disabled
*<br><b> CPD_ON: </b> Data memory code protection is enabled
*
*<hr>
*@subsection BOR Brown-out Reset Enable
*<br><b> BOREN_ON: </b>Brown-out Reset enabled
*<br><b> BOREN_NSLEEP: </b>Brown-out Reset enabled while running and disabled in Sleep
*<br><b> BOREN_SBODEN: </b>Brown-out Reset controlled by the SBOREN bit in the BORCON register
*<br><b> BOREN_OFF: </b>Brown-out Reset disabled
*
*<hr>
*@subsection CO Clock Out Enable
*<br><b> CLKOUTEN_OFF: </b>CLKOUT function is disabled. I/O or oscillator function on the CLKOUT pin
*<br><b> CLKOUTEN_ON: </b>CLKOUT function is enabled on the CLKOUT pin
*
*<hr>
*@subsection IE Internal/External Switchover
*<br><b> IESO_ON: </b>Internal/External Switchover mode is enabled
*<br><b> IESO_OFF: </b>Internal/External Switchover mode is disabled
*
*<hr>
*@subsection FSCM Fail-Safe Clock Monitor Enable
*<br><b> FCMEN_ON: </b>Fail-Safe Clock Monitor is enabled
*<br><b> FCMEN_OFF: </b>Fail-Safe Clock Monitor is disabled
*
*<hr>
*<br> @section CR2 Config Register: CONFIG2
*@subsection FMSW Flash Memory Self-Write Protection
*<br><b> WRT_OFF: </b>Write protection off
*<br><b>  WRT_BOOT: </b>000h to 1FFh write protected, 200h to 1FFFh may be modified by EECON control
*<br><b>  WRT_HALF: </b>000h to FFFh write protected, 1000h to 1FFFh may be modified by EECON control
*<br><b>  WRT_ALL: </b>000h to 1FFFh write protected, no addresses may be modified by EECON control
*
*<hr>
*@subsection VR Voltage Regulator Capacitor Enable
*<br><b>  VCAPEN_OFF: </b>All VCAP pin functionality is disabled
*<br><b>  VCAPEN_RA6: </b>VCAP functionality is enabled on RA6
*<br><b>  VCAPEN_RA5: </b>VCAP functionality is enabled on RA5
*<br><b>  VCAPEN_RA0: </b>VCAP functionality is enabled on RA0
*
*<hr>
*@subsection PLL PLL Enable
*<br><b>  PLLEN_ON: </b>4x PLL enabled
*<br><b>  PLLEN_OFF: </b>4x PLL disabled
*
*<hr>
*@subsection SOU Stack Overflow/Underflow Reset Enable
*<br><b>  STVREN_ON: </b>Stack Overflow or Underflow will cause a Reset
*<br><b>  STVREN_OFF: </b>Stack Overflow or Underflow will not cause a Reset
*
*<hr>
*@subsection BORV Brown-out Reset Voltage Selection
*<br><b>  BORV_19: </b>Brown-out Reset Voltage (VBOR) set to 1.9 V
*<br><b>  BORV_25: </b>Brown-out Reset Voltage (VBOR) set to 2.5 V
*
*<hr>
*@subsection LVP Low-Voltage Programming Enable
*<br><b>  LVP_ON: </b>Low-voltage programming enabled
*<br><b>  LVP_OFF: </b>High-voltage on MCLR/VPP must be used for programming
*/
/** @page P18CWList PIC18F46K22 Configuration Word Options
*<br> @section CR18 Config Register
*<hr>
* @subsection OSCSB    Oscillator Selection bits:
* <br><b>      FOSC = LP</b>:            LP oscillator
* <br><b>      FOSC = XT</b>:            XT oscillator
* <br><b>      FOSC = HSHP</b>:          HS oscillator (high power > 16 MHz)
* <br><b>      FOSC = HSMP</b>:          HS oscillator (medium power 4-16 MHz)
* <br><b>      FOSC = ECHP</b>:          EC oscillator, CLKOUT function on OSC2 (high power, >16 MHz)
* <br><b>      FOSC = ECHPIO6</b>:       EC oscillator, port function on RA6 (high power, >16 MHz)
* <br><b>      FOSC = RC</b>:            External RC, CLKOUT on OSC2
* <br><b>      FOSC = RCIO6</b>:         External RC oscillator, port function on RA6
* <br><b>      FOSC = INTIO67</b>:       Internal oscillator block, port function on RA6 and RA7
* <br><b>      FOSC = INTIO7</b>:        Internal oscillator block, CLKOUT function on RA6, port function on RA7
* <br><b>      FOSC = ECMP</b>:          EC oscillator, CLKOUT on OSC2 (medium power, 4-16 MHz)
* <br><b>      FOSC = ECMPIO6</b>:       EC oscillator (medium power, 4-16 MHz)
* <br><b>      FOSC = ECLP</b>:          EC oscillator, CLKOUT on OSC2 (low power, < 4 MHz)
* <br><b>      FOSC = ECLPIO6</b>:       EC oscillator  (low power, < 4 MHz)
*
*<hr>
* @subsection PLL18    4X PLL Enable:
* <br><b>      PLLCFG = OFF</b>:         Oscillator used directly
* <br><b>      PLLCFG = ON</b>:          Oscillator multiplied by 4
*
*<hr>
* @subsection PC18    Primary clock enable bit:
* <br><b>      PRICLKEN = OFF</b>:       Primary clock can be disabled by software
* <br><b>      PRICLKEN = ON</b>:        Primary clock is always enabled
*
*<hr>
* @subsection FSCM18   Fail-Safe Clock Monitor Enable bit:
* <br><b>      FCMEN = OFF</b>:          Fail-Safe Clock Monitor disabled
* <br><b>      FCMEN = ON</b>:           Fail-Safe Clock Monitor enabled
*
*<hr>
* @subsection IEO18    Internal/External Oscillator Switchover bit:
* <br><b>      IESO = OFF</b>:           Oscillator Switchover mode disabled
* <br><b>      IESO = ON</b>:            Oscillator Switchover mode enabled
*
*<hr>
* @subsection PUT18    Power-up Timer Enable bit:
* <br><b>      PWRTEN = ON</b>:          Power up timer enabled
* <br><b>      PWRTEN = OFF</b>:         Power up timer disabled
*
*<hr>
* @subsection BOR18    Brown-out Reset Enable bits:
* <br><b>      BOREN = OFF</b>:          Brown-out Reset disabled in hardware and software
* <br><b>      BOREN = ON</b>:           Brown-out Reset enabled and controlled by software (SBOREN is enabled)
* <br><b>      BOREN = NOSLP</b>:        Brown-out Reset enabled in hardware only and disabled in Sleep mode (SBOREN is disabled)
* <br><b>      BOREN = SBORDIS</b>:      Brown-out Reset enabled in hardware only (SBOREN is disabled)
*
*<hr>
* @subsection BORV18    Brown Out Reset Voltage bits:
* <br><b>      BORV = 285</b>:           VBOR set to 2.85 V nominal
* <br><b>      BORV = 250</b>:           VBOR set to 2.50 V nominal
* <br><b>      BORV = 220</b>:           VBOR set to 2.20 V nominal
* <br><b>      BORV = 190</b>:           VBOR set to 1.90 V nominal
*
*<hr>
* @subsection WDT18   Watchdog Timer Enable bits:
* <br><b>      WDTEN = OFF</b>:          Watch dog timer is always disabled. SWDTEN has no effect.
* <br><b>      WDTEN = NOSLP</b>:        WDT is disabled in sleep, otherwise enabled. SWDTEN bit has no effect
* <br><b>      WDTEN = SWON</b>:         WDT is controlled by SWDTEN bit of the WDTCON register
* <br><b>      WDTEN = ON</b>:           WDT is always enabled. SWDTEN bit has no effect
*
*<hr>
* @subsection WDTP18    Watchdog Timer Postscale Select bits:
* <br><b>      WDTPS = 1</b>:            1:1
* <br><b>      WDTPS = 2</b>:            1:2
* <br><b>      WDTPS = 4</b>:            1:4
* <br><b>      WDTPS = 8</b>:            1:8
* <br><b>      WDTPS = 16</b>:           1:16
* <br><b>      WDTPS = 32</b>:           1:32
* <br><b>      WDTPS = 64</b>:           1:64
* <br><b>      WDTPS = 128</b>:          1:128
* <br><b>      WDTPS = 256</b>:          1:256
* <br><b>      WDTPS = 512</b>:          1:512
* <br><b>      WDTPS = 1024</b>:         1:1024
* <br><b>      WDTPS = 2048</b>:         1:2048
* <br><b>      WDTPS = 4096</b>:         1:4096
* <br><b>      WDTPS = 8192</b>:         1:8192
* <br><b>      WDTPS = 16384</b>:        1:16384
* <br><b>      WDTPS = 32768</b>:        1:32768
*
*<hr>
* @subsection CCP218    CCP2 MUX bit:
* <br><b>      CCP2MX = PORTB3</b>:      CCP2 input/output is multiplexed with RB3
* <br><b>      CCP2MX = PORTC1</b>:      CCP2 input/output is multiplexed with RC1
*
*<hr>
* @subsection PORTB18    PORTB A/D Enable bit:
* <br><b>      PBADEN = OFF</b>:         PORTB<5:0> pins are configured as digital I/O on Reset
* <br><b>      PBADEN = ON</b>:          PORTB<5:0> pins are configured as analog input channels on Reset
*
*<hr>
* @subsection P3A18    P3A/CCP3 Mux bit:
* <br><b>      CCP3MX = PORTE0</b>:      P3A/CCP3 input/output is mulitplexed with RE0
* <br><b>      CCP3MX = PORTB5</b>:      P3A/CCP3 input/output is multiplexed with RB5
*
*<hr>
* @subsection HFINT18    HFINTOSC Fast Start-up
* <br><b>      HFOFST = OFF</b>:         HFINTOSC output and ready status are delayed by the oscillator stable status
* <br><b>      HFOFST = ON</b>:          HFINTOSC output and ready status are not delayed by the oscillator stable status
*
*<hr>
* @subsection Timer318   Timer3 Clock input mux bit:
* <br><b>      T3CMX = PORTB5</b>:       T3CKI is on RB5
* <br><b>      T3CMX = PORTC0</b>:       T3CKI is on RC0
*
*<hr>
* @subsection ECCP218    ECCP2 B output mux bit:
* <br><b>      P2BMX = PORTC0</b>:       P2B is on RC0
* <br><b>      P2BMX = PORTD2</b>:       P2B is on RD2
*
*<hr>
* @subsection MCLR18    MCLR Pin Enable bit:
* <br><b>      MCLRE = INTMCLR</b>:      RE3 input pin enabled; MCLR disabled
* <br><b>      MCLRE = EXTMCLR</b>:      MCLR pin enabled, RE3 input pin disabled
*
*<hr>
* @subsection SFU18    Stack Full/Underflow Reset Enable bit:
* <br><b>      STVREN = OFF</b>:         Stack full/underflow will not cause Reset
* <br><b>      STVREN = ON</b>:          Stack full/underflow will cause Reset
*
*<hr>
* @subsection SS18    Single-Supply ICSP Enable bit:
* <br><b>      LVP = OFF</b>:            Single-Supply ICSP disabled
* <br><b>      LVP = ON</b>:             Single-Supply ICSP enabled if MCLRE is also 1
*
*<hr>
* @subsection EI18    Extended Instruction Set Enable bit:
* <br><b>      XINST = OFF</b>:          Instruction set extension and Indexed Addressing mode disabled (Legacy mode)
* <br><b>      XINST = ON</b>:           Instruction set extension and Indexed Addressing mode enabled
*
*<hr>
* @subsection BD18    Background Debug:
* <br><b>      DEBUG = ON</b>:           Enabled
* <br><b>      DEBUG = OFF</b>:          Disabled
*
*<hr>
* @subsection CP018    Code Protection Block 0:
* <br><b>      CP0 = ON</b>:             Block 0 (000800-001FFFh) code-protected
* <br><b>      CP0 = OFF</b>:            Block 0 (000800-001FFFh) not code-protected
*
*<hr>
* @subsection CP118    Code Protection Block 1:
* <br><b>      CP1 = ON</b>:             Block 1 (002000-003FFFh) code-protected
* <br><b>      CP1 = OFF</b>:            Block 1 (002000-003FFFh) not code-protected
*
*<hr>
* @subsection CP218    Code Protection Block 2:
* <br><b>      CP2 = ON</b>:             Block 2 (004000-005FFFh) code-protected
* <br><b>      CP2 = OFF</b>:            Block 2 (004000-005FFFh) not code-protected
*
*<hr>
* @subsection CP318    Code Protection Block 3:
* <br><b>      CP3 = ON</b>:             Block 3 (006000-007FFFh) code-protected
* <br><b>      CP3 = OFF</b>:            Block 3 (006000-007FFFh) not code-protected
*
*<hr>
* @subsection BBC18    Boot Block Code Protection bit:
* <br><b>      CPB = ON</b>:             Boot block (000000-0007FFh) code-protected
* <br><b>      CPB = OFF</b>:            Boot block (000000-0007FFh) not code-protected
*
*<hr>
* @subsection DEE18   Data EEPROM Code Protection bit:
* <br><b>      CPD = ON</b>:             Data EEPROM code-protected
* <br><b>      CPD = OFF</b>:            Data EEPROM not code-protected
*
*<hr>
* @subsection WP018    Write Protection Block 0:
* <br><b>      WRT0 = ON</b>:            Block 0 (000800-001FFFh) write-protected
* <br><b>      WRT0 = OFF</b>:           Block 0 (000800-001FFFh) not write-protected
*
*<hr>
* @subsection WP118    Write Protection Block 1:
* <br><b>      WRT1 = ON</b>:            Block 1 (002000-003FFFh) write-protected
* <br><b>      WRT1 = OFF</b>:           Block 1 (002000-003FFFh) not write-protected
*
*<hr>
* @subsection WP218    Write Protection Block 2:
* <br><b>      WRT2 = ON</b>:            Block 2 (004000-005FFFh) write-protected
* <br><b>      WRT2 = OFF</b>:           Block 2 (004000-005FFFh) not write-protected
*
*<hr>
* @subsection WP318    Write Protection Block 3:
* <br><b>      WRT3 = ON</b>:            Block 3 (006000-007FFFh) write-protected
* <br><b>      WRT3 = OFF</b>:           Block 3 (006000-007FFFh) not write-protected
*
*<hr>
* @subsection CRW18    Configuration Register Write Protection bit:
* <br><b>      WRTC = ON</b>:            Configuration registers (300000-3000FFh) write-protected
* <br><b>      WRTC = OFF</b>:           Configuration registers (300000-3000FFh) not write-protected
*
*<hr>
* @subsection BBW18    Boot Block Write Protection bit:
* <br><b>      WRTB = ON</b>:            Boot Block (000000-0007FFh) write-protected
* <br><b>      WRTB = OFF</b>:           Boot Block (000000-0007FFh) not write-protected
*
*<hr>
* @subsection EEW18    Data EEPROM Write Protection bit:
* <br><b>      WRTD = ON</b>:            Data EEPROM write-protected
* <br><b>      WRTD = OFF</b>:           Data EEPROM not write-protected
*
*<hr>
* @subsection TRP18    Table Read Protection Block 0:
* <br><b>      EBTR0 = ON</b>:           Block 0 (000800-001FFFh) protected from table reads executed in other blocks
* <br><b>      EBTR0 = OFF</b>:          Block 0 (000800-001FFFh) not protected from table reads executed in other blocks
*
*<hr>
* @subsection TRP118    Table Read Protection Block 1:
* <br><b>      EBTR1 = ON</b>:           Block 1 (002000-003FFFh) protected from table reads executed in other blocks
* <br><b>      EBTR1 = OFF</b>:          Block 1 (002000-003FFFh) not protected from table reads executed in other blocks
*
*<hr>
* @subsection TRP218    Table Read Protection Block 2:
* <br><b>      EBTR2 = ON</b>:           Block 2 (004000-005FFFh) protected from table reads executed in other blocks
* <br><b>      EBTR2 = OFF</b>:          Block 2 (004000-005FFFh) not protected from table reads executed in other blocks
*
*<hr>
* @subsection TRP318    Table Read Protection Block 3:
* <br><b>      EBTR3 = ON</b>:           Block 3 (006000-007FFFh) protected from table reads executed in other blocks
* <br><b>      EBTR3 = OFF</b>:          Block 3 (006000-007FFFh) not protected from table reads executed in other blocks
*
*<hr>
* @subsection BBTR18    Boot Block Table Read Protection bit:
* <br><b>      EBTRB = ON</b>:           Boot Block (000000-0007FFh) protected from table reads executed in other blocks
* <br><b>      EBTRB = OFF</b>:          Boot Block (000000-0007FFh) not protected from table reads executed in other blocks
*/
/**
* @page BPSetup Setting up and Programming the PICDEM 2 Plus
* @subpage PP <br>
* @subpage PC <br>
* @subpage SC
*/
/**
* @page PP	Programming the PIC
*	@section Prog	Programmers
*<hr>
*	@subsection PK3	PICKIT3
*   @image html PicKit3.jpg "PICKIT3 communicator"
*	<p> Microchip's PICKIT 3 In-Circuit Debugger/Programmer uses in-circuit debugging logic
*   incorporated into each chip with Flash memory to provide a low-cost harware debugger and programmer. </p>
* 	@subsection Con	Connecting the PICKIT3
*	@image html PPK3.jpg	"PICKIT Connector"
*	<p> Connecting the PICKIT3 to the PICDEM 2 PLUS board is quick and easy. </p>
*	<ul> <li> First connect the PICKIT3 to the marked [A] connector. </li>
*   <li> Make sure to connect the USB cable to the PICKIT3 and to the computer. </li>
*   <li> Enter MPLab and go to either the [Debugger or Programmer] Tab. Select the PICKIT3 as shown below. </li></ul>
*	@image html PKMP.png "Connecting the PICKIT3 to MPLAB"
*<hr>
*	@subsection ICD3	In-Circuit Debugger 3 [ICD3]
*   @image html ICD3.jpg "ICD3 Communicator"
*	<p> MPLAB ICD3 In-Circuit Debugger System is Microchip's most cost effective high-speed hardware
*   debugger/programmer for Microchip Flash Digital Signal Controller (DSC) and microcontroller (MCU) devices.
*	It debus and programs PIC Flash microcontrollers and dsPIC DSCs with the powerful, yet easy-to-use graphical user
*   interface of MPLAB Integrated Development Environment (IDE). </p>
* 	@subsection ConICD	Connecting the ICD3
*	@image html PICD3.jpg	"ICD Connector"
*	<p> Connecting the ICD3 to the PICDEM 2 PLUS board is quick and easy. <p>
*	<ul> <li> First connect the ICD3 to the marked [B] connector. </li>
*   <li> Make sure to connect the USB cable to the ICD3 and to the computer. </li>
*   <li> Enter MPLab and go to either the [Debugger or Programmer] Tab. Select the ICD3 as shown below. </li></ul>
*
*	@image html 1.png	"Connecting the ICD3 to MPLAB"
* <hr>
*/
/**
* @page PC	Powering the PICDEM 2 PLUS Board
*	@section P	Power Sources
*<hr>
*	@subsection EX9	External 9V connector
*   @image html 9V.jpg "9 Volt Power Supply"
*	<p> You can power the PICDEM 2 Plus board with an External 9 V Power Supply. </p>
*	<ul> <li> Connect 9V Power Supply to a Wall outlet. </li>
*	<li> Connect to Board [A]. The onboard regulator will reduce the input voltage to 5V for safe PIC operation.
*	<br>@image html 9VC.jpg "External 9 Volt Connections"
*<hr>
*	@subsection BAT9	External 9V Battery Connector
*   @image html 9VBat.jpg "9 Volt Battery"
*	<p> You can power the PICDEM 2 Plus board with an External 9 V Battery for a Power Supply. </p>
*	<ul><li> Connect the 9V battery to the Board [B]. </li>
*	<li> The onboard regulator will reduce the input voltage to 5V for safe PIC operation. </li> </ul>
*<hr>
*	@subsection PD	Power by Programmer
*   @image html PBP.png "Power using your programming device"
*	<p> You can also power the PICDEM 2 Plus board with your programming device [PICKIT3 or ICD3] </p>
*	<ul><li> To Power your device with your programmer go to either the Debuggger/Programmer Tab. </li>
*	<li> Scroll down to Settings. Then go to the POWER tab. </li>
*	<li> Click the checkbox labeled "Power target circuit from MPLAB [programmer type]". Select 5V as your Voltage. </li>
*	<li> The board will now be powered through your programmer. </li></ul>
* <hr>
*/
/**
* @page SC	Establishing RS232/Serial Communication
*	@section SD	Serial Communication Devices
*<hr>
*	@subsection RS232	RS232 Communicator
*	@image html RS232cable.jpg	"RS232 Cable"
*	<ul> <li> To establish communication between the PICDEM 2 PLUS board and a computer.
*	Simply connect the cable to the RS232 connector [C] located on the board.</li> </ul>
*	@image html RS232.jpg "RS232 Connector"
*	<ul> <li> Once the cable is connected make sure to select the correct COM PORT & match the configuration below.
*	</li></ul> @image html SerialConfig.jpg	"Serial Communication Configuration"
*<hr>
*	@subsection PSerial	PICSerial Communicator
*	@image html PicSerial.jpg	"PIC Serial Analyser"
*	<ul> <li> First make sure to setup the PIC Serial Analyser. @subpage PKSARS232</li>
*	<li> Once setup correctly simply connect the PIC Serial Analyser to the PICSerial connection [D].</li> </ul>
*	@image html Serial.jpg "PIC Serial Connector"
*	<ul> <li> Once the cable is connected make sure to select the correct COM PORT & match the configuration below.
*	</li></ul> @image html SerialConfig.jpg	"Serial Communication Configuration"
*<hr>
*	@subsection Success	Successful Communication
*	<b> EXAMPLE: </b>
*	@image html com.png	"RS232-to-Computer Communication"
*/
/**
* @page PKSARS232 Converting the PICKit Serial Analyser into an RS232-to-USB converter
*
* @section Intro Introduction
* The PICKit Serial Analyzer (PKSA) is an easy way to connect the UART of your PIC&reg; microcontroller to your PC. All of the required files are located in the framework's root @c extras/ folder. 
*
* <b>Maximum Speed</b>: 115.2 kbps<br>
* <b>Voltage Level</b>: Depends on the voltage applied to pin #2. Valid range is from 3-5V.<br>
* Optional 5V (<20mA) power supply from the PICKit Serial Analyzer.<br>
*
* @section Convert Changing Your PICKit Serial Analyzer into an RS-232 Converter
* <ol>
* <li>Press the button on the PICKit Serial Analyzer when connecting to PC's USB to enter @c Bootloader @c Mode.<br>
*     (The 'Target' and 'Busy' LEDs should be flashing quickly.)
* <li>Open the PICKit Serial Analyzer PC software.
*  <ul>
*  <li>Close the Wizard window that automatically appears on startup.
*  <li>The terminal window should confirm that you are in Bootloader mode.
*  <li>Navigate to <b>PICKit Serial Analyzer --> Download PICKit Serial Analyzer Firmware</b>
*  <li>Browse and open the PKSA RS232 hex file.
*  <li>Wait for the reflashing process to complete. This may take a few minutes.
*  </ul>
* @image html pksaSS.JPG
* <li>Once complete, a Windows driver wizard will appear.
*  <ul><li><b>DO NOT EXIT OUT OF THIS WINDOW.</b> If you do, you'll need to manually install the INF file.</ul>
* <li>Point the driver wizard to the provided .inf file. This will allow windows to treat the USB connection as a COM port.
* </ol>
*
* @section Use Using your RS-232 Converter
* <ol>
* <li>Unplug and replug the PKSA. Press and hold the black PKSA button to toggle the on-board 5V power supply.
*  <ul><li>Warning: There is no protection provided on this power supply. Maximum current is 20mA.</ul>
* <li>LED Status Legend:
*  <ul>
*  <li>Target LED On: Transmission in progress
*  <li>Busy LED On: Reception was successful
*  </ul>
* </ol>
*
* @image html pksaExtVdd.JPG "Example schematic connecting the PKSA with an external power supply"
* @image html pksaVdd.JPG "Example schematic of PKSA supplying power to the board"
* @image html pksaExt5Vdd.JPG "Example schematic of connecting PKSA with an external 5V power supply. Notice - no V<sub>DD</sub> connection required.
*
* @section Pinout PICKit Serial Analyzer Pin Configuration
* <ol>
* <li>The PC's TX line. The PIC's RX line. (Marked with an arrow)
* <li>V<sub>DD</sub> : 3-5V
* <li>V<sub>SS</sub>
* <li>Aux1 : not used in RS232 configuration
* <li>Aux2 : not used in RS232 configuration
* <li>The PC's RX line. The PIC's TX line.
* </ol>
* @image html pksaPins.JPG
*/
/**
* @page StartUp PICDEM 2 Plus Splash Menu
* @section Splash Initial State
* @image html Splash.jpg "Splash Menu"
* <br> <p> The first 2 secounds of the program are dedicated to starting the program, configure
* OSSCCON register for system clock, configure the device pins for input/out function, 
* configure peripherals for use, enable interrupts, test the LCD functionality, 
* enter main state machine, move to Voltmeter function. <br>
*<br> <b> NOTE:* </b> Initial State [Splash Menu] is only entered on device startup/restart.
* <hr>
* @section SUF	Start Up Failure
* @image html LCDFault.jpg "LCD Failure"
* <br> If the LCD wait period is too short the display will fail. To simulate this failure the variable 
* [TimeOut_Max] has been defined in LCD.C. If an LCD_Wait Timeout Failure occurs [RB3:RB1] LED's will turn on
* to indicate the failure. 
*
*/ 
/**
* @page Voltmeter 10 bit ADC Voltermeter Operation
* @section VoltMenu Voltmeter Menu
* @image html Voltmeter.jpg "Voltmeter Menu"
* <br> <p> The program will enter this state:<br>
* <ul>
* <li> <b> a) </b> After exiting Splash Menu State </li>
* <li> <b> b) </b> After exiting Clock Menu State  </li>
* </ul> 
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RA4: [Next] </b> - Move to the next state. [Buzzer] </li>
* <li> <b> RB0: [Now] </b> -  Enter Voltmeter Function</li>
* </ul><hr>
*
* @section VoltDis Voltmeter Function
* @image html Volts.jpg "Voltmeter Display"
*
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RB0: [Now] </b> -  Exit Voltmeter Function</li>
* </ul><hr>
* @section VADC	Perpheials Used
* @subsection VP	Analog-to-Digital Converter [ADC]
* @image html BPot.jpg "On Board Potentiometer"
* <br> 
* <p> The Analog-to-Digital Converter [ADC] allows conversion of an analog
* input signal to a 10-bit binary represtation of that signal. The 
* converter generates a 10-bit binary result via successive approximation
* and stores the conversion result into the ADC result registers. [ADRESH:ADRESL] </p>
*
* @subsection RADC	Reading the Voltmeter Display [ADC]
* @image html RVolts.jpg "Voltmeter"
* <ul> <li> <b> A] </b> [ADRESH:ADRESL] ADC conversion result. Range: 10-bit [0 - 1023] </li>
* <li> <b> B] </b> Voltage representation. 
* </li> </ul>
* @subsection Math	MATH
* Vdd= 5V;      Vss = 0V;        [ADRESH:ADRESL] = 726. 
* <br> <br> Equation: ([ADRESH:ADRESL]/1023) * (Vdd-Vss)
* <br> <br> Calculated: ([726]/1023)*(5) = 3.55
* <hr>
* @section Setup	ADC Register Setup
* @subsection ADCON0 A/D Control Register 0
* <ul> 
* <li> <b> CHS<4:0>:</b> <00000> = AN0 [RA0] - Select Analog Channel for input </li>
* <li> <b> GO/nDONE:</b> <0> - Bit which indicates if a conversion is in process </li>
* <li> <b> ADON: </b> <1> - ADC Enable Bit </li>
* </ul>
* @subsection ADCON1 A/D Control Register 1
* <ul> 
* <li> <b> ADFM:</b> <1> - ADC is Right justfied </li>
* <li> <b> ADCS<2:0></b> <111> - FRC(clock supplied from a dedicated RC oscillator) </li>
* <li> <b> ADNREF: </b> <0> - Vref- is set to Vss </li>
* <li> <b> ADPREF: </b> <0> - Vref+ is set to Vdd </li>
* </ul>
* <br> <hr>
* @subpage ADCBD	ADC Block Diagram <br>
* @subpage ADCR		ADC Registers
*/
/**
* @page ADCBD	ADC Block Diagram
* @image html ADC_BD.png "ADC Block Diagram"
*/
/**
* @page ADCR		ADC Registers
* @image html ADCON0.png "A/D Control Register 0"
** @image html ADCON1.png "A/D Control Register 1"
*/
/**
* @page Buzzer 8-ohm Speaker Buzzer Operation
* @section BuzzMenu Buzzer Menu
* @image html BuzzMenu.jpg "Buzzer Menu"
* <br> <p> The program will enter this state:<br>
* <ul>
* <li> <b> a) </b> After exiting Voltmeter Menu State </li>
* </ul> 
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RA4: [Next] </b> - Move to the next state. [Temperature] </li>
* <li> <b> RB0: [Now] </b> -  Enter Buzzer Function</li>
* </ul><hr>
*
* @section BuzzDis Buzzer Function
* @image html PWM.jpg "Buzzer Display"
*
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RA4: [+2%] </b> -  Increase Pulse Width Modulators Period size by 2%. [0-100% Range] 
* This will alter the frequency </li>
* <li> <b> RB0: [Now] </b> -  Exit Buzzer Function</li>
* </ul><hr>
* @section BuzzP	Perpheials Used
* @subsection BP	Enhanced Capture/Compare/Pulse Width Modules [ECCP]
* @image html BBuzzer.jpg "On Board 8-ohm Speaker"
* <br> 
* <p> The Capture/Compare/PWM module is a peripheral which allows the user to time
* and control different events, and to generate Pulse-Width Modulation (PWM) signals. The PWM mode
* can generate Pulse-Width Modulated signals of varying frequency and duty cycle. </p>
* @subsection Timer4	Timer 4
* <p> Timer 4 is used by the ECCP1 to create a time base. Timers 2/4/6 may all be used to create a PWM signal. 
*
* @subsection RBuzzD	Reading the Buzzer Display
* @image html RBuzz.jpg "Buzzer Display"
* <ul> <li> <b> A] </b> PWM Period Percentage. Range[0-100%] Frequency [10KHz - 250Hz]; 
* @subpage FullList </li>
* <li> <b> B] </b> This is the key being played based on the frequency being supplied to the speaker. 
* </li> 
* <li> <b> C] </b> Increase the PWM period by 2% </li> 
*</ul>
* @subsection MathB	MATH
* @image html Signal.png "Buzzer Supplied Frequency [PWM:22%]"
* T4Osc = 4Mhz;      Timer4_Scaler = 16;       Period = This is dependent on PWM%
* <br> <br> Equation: [Buzzer Frequency] = {[(T4osc / 4) / T4_Scaler] / Period}
* <br> <br> Calculated [Picture Example]: {[(4Mhz/4) / (16)] / 60} ~= 1.04KHz Key
* <b> <br> NOTE* </b> : All supplied "Keys" are based off a System clock of 4Mhz.
* <hr>
* @section SetupB	ECCP Register Setup
* @subsection CCPCON0 CCPxCON: Enhanced CCPx Control Register
* <ul> 
* <li> <b> PxM<1:0>:</b> <00> = Full-Bridge ECCP Module: Single Output </li>
* <li> <b> DCxB<1:0>:</b> <00> - Load the LSB's for the PWM Duty Cycle </li>
* <li> <b> CCPxM<3:0>: </b> <1100> - PWM Mode: PxA, PxC active-high; PxB, PxD active-high </li>
* </ul>
* @subsection CCPTMRS0 CCPTMRS0: PWM Timer Selection Control Register 0
* <ul> 
* <li> <b> C3TSEL <1:0> :</b> <00> - CCP3 - Capture/Compare Modes use Timer1, PWM modes use Timer2 </li>
* <li> <b> C2TSEL <1:0> :</b> <00> - CCP2 - Capture/Compare Modes use Timer1, PWM modes use Timer2 </li>
* <li> <b> C1TSEL <1:0> :</b> <01> - CCP1 - Capture/Compare Modes use Timer3, PWM modes use Timer4  </li>
* </ul>
* @subsection TMR4 TxCON: Timer2/Timer4/Timer6 Control Register
* <ul> 
* <li> <b> TxOUTPS <3:0> :</b> <0000> - 1:1 Postscaler </li>
* <li> <b> TMRxON :</b> <1> - TimerX [4] is on </li>
* <li> <b> TxCKPS <1:0> :</b> <1x> - Prescaler is 16  </li>
* </ul>
* <b> NOTE* </b> : Postscalers DO NOT effect PWM
* <br> <hr>
* @subpage PWMBC	<br>
* @subpage PWMR		 <br>
* @subpage TR		
*/
/**
* @page FullList	Full Period % to Frequency List
* <ul>
* <li>PWM:0%   :		Period 5: 	[Frequency:	10 KHz] </li>		
* <li>PWM:2%   :		Period 10: 	[Frequency:	5 KHz] </li>
* <li>PWM:4%   :		Period 15: 	[Frequency:	4 KHz] </li> 
* <li>PWM:6%   :		Period 20: 	[Frequency:	3 KHz] </li> 
* <li>PWM:8%   :		Period 25: 	[Frequency:	2.45 KHz] </li>
* <li>PWM:10%  :		Period 30: 	[Frequency:	2 KHz] </li>
* <li>PWM:12%  :		Period 35: 	[Frequency:	1.73 KHz] </li> 
* <li>PWM:14%  :		Period 40: 	[Frequency:	1.52 KHz] </li> 
* <li>PWM:16%  :		Period 45: 	[Frequency:	1.36 KHz] </li>
* <li>PWM:18%  :		Period 50: 	[Frequency:	1.23 KHz] </li>
* <li>PWM:20%  :		Period 55: 	[Frequency:	1.16 KHz] </li> 
* <li>PWM:22%  :		Period 60: 	[Frequency:	1.03 KHz] </li> 
* <li>PWM:24%  :		Period 65: 	[Frequency:	950 Hz] </li>
* <li>PWM:26%  :		Period 70: 	[Frequency:	880 Hz] </li>
* <li>PWM:28%  :		Period 75: 	[Frequency:	823 Hz] </li> 
* <li>PWM:30%  :		Period 80: 	[Frequency:	775 Hz] </li> 
* <li>PWM:32%  :		Period 85: 	[Frequency:	730 Hz] </li>
* <li>PWM:34%  :		Period 90: 	[Frequency:	690 Hz] </li>
* <li>PWM:36%  :		Period 95: 	[Frequency:	653 Hz] </li> 
* <li>PWM:38%  :		Period 100: 	[Frequency:	620 Hz] </li> 
* <li>PWM:40%  :		Period 105: 	[Frequency:	590 Hz] </li>
* <li>PWM:42%  :		Period 110: 	[Frequency:	560 Hz] </li>
* <li>PWM:44%  :		Period 115: 	[Frequency:	530 Hz] </li> 
* <li>PWM:46%  :		Period 120: 	[Frequency:	510 Hz] </li> 
* <li>PWM:48%  :		Period 125: 	[Frequency:	495 Hz] </li> 
* <li>PWM:50%  :		Period 130: 	[Frequency:	478 Hz] </li> 
* <li>PWM:52%  :		Period 135: 	[Frequency:	460 Hz] </li>
* <li>PWM:54%  :		Period 140: 	[Frequency:	442 Hz] </li>
* <li>PWM:56%  :		Period 145: 	[Frequency:	427 Hz] </li> 
* <li>PWM:58%  :		Period 150: 	[Frequency:	414 Hz] </li> 
* <li>PWM:60%  :		Period 155: 	[Frequency:	400 Hz] </li> 
* <li>PWM:62%  :		Period 160: 	[Frequency:	390 Hz] </li>
* <li>PWM:64%  :		Period 165: 	[Frequency:	375 Hz] </li>
* <li>PWM:66%  :		Period 170: 	[Frequency:	365 Hz] </li> 
* <li>PWM:68%  :		Period 175: 	[Frequency:	355 Hz] </li> 
* <li>PWM:70%  :		Period 180: 	[Frequency:	345 Hz] </li>
* <li>PWM:72%  :		Period 185: 	[Frequency: 335 Hz] </li> 
* <li>PWM:74%  :		Period 190: 	[Frequency:	326 Hz] </li>
* <li>PWM:76%  :		Period 195: 	[Frequency:	318 Hz] </li>
* <li>PWM:78%  :		Period 200: 	[Frequency:	310 Hz] </li> 
* <li>PWM:80%  :		Period 205: 	[Frequency:	300 Hz] </li> 
* <li>PWM:82%  :		Period 210: 	[Frequency:	295 Hz] </li> 
* <li>PWM:84%  :		Period 215: 	[Frequency:	290 Hz] </li>
* <li>PWM:86%  :		Period 220: 	[Frequency:	284 Hz] </li>
* <li>PWM:88%  :		Period 225: 	[Frequency:	277 Hz] </li> 
* <li>PWM:90%  :		Period 230: 	[Frequency:	270 Hz] </li> 
* <li>PWM:92%  :		Period 235: 	[Frequency:	264 Hz] </li>
* <li>PWM:94%  :		Period 240: 	[Frequency:	259 Hz] </li>
* <li>PWM:96%  :		Period 245: 	[Frequency:	254 Hz] </li> 
* <li>PWM:98%  :		Period 250: 	[Frequency: 249 Hz] </li> 
* <li>PWM:100% :	    Period 255: 	[Frequency:	245 Hz] </li>
*</ul>
*/
/**
* @page PWMR		PWM Registers
* @section PIC16	PIC16F1937
* @image html CCPxCON_Reg.png "CCP1 Config Register"
* @image html CCPTMRS0_Reg.png "PWM Timer Selection Control Register"
* <hr>
* @section PIC18	PIC18F46K22
* @image html CCPxCON_Reg18.png
* @image html CCPxCON_Reg182.png "CCP1 Config Register"
* @image html CCPTMRS0_Reg18.png "PWM Timer Selection Control Register"
*/
/**
* @page PWMBC PWM Block Diagram
* @image html PWM_BD.png "Pulse Width Modulator Block Diagram"
*/
/**
* @page TR Timer Register
* @image html TimerR.png "Pulse Width Modulator Block Diagram"
* <b> NOTE* </b> : The PIC16F1937 also has an additional prescaler. <11> - Prescaler is 64
*/
/**
* @page Temperature I2C Temperature Indicator Operation
* @section TempMenu Temperature Menu
* @image html TempMenu.jpg "Temperature Menu"
* <br> <p> The program will enter this state:<br>
* <ul>
* <li> <b> a) </b> After exiting Voltmeter Menu State </li>
* </ul> 
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RA4: [Next] </b> - Move to the next state. [Clock] </li>
* <li> <b> RB0: [Now] </b> -  Enter Temperature Function</li>
* </ul><hr>
*
* @section TempFault Temperature Fault
* @image html TempFault.jpg "I2C Communication Failure"
* <b> NOTE* : </b> If during I2C communication a timeout fault occurs, this is the error that is seen.
* To simulate this failure the variable [TO_Max] has been defined in I2C.c.
* <hr>
* @section TempDis Temperature Function
* @image html TempC.jpg "Celsius Display"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RB0: [Now] </b> -  Switch between Fahrenheit & Celsius</li>
* <li> <b> RB0: [Now] </b> -  Exit Temperature Function</li>
* </ul>
** @image html TempF.jpg "Fahrenheit Display" <hr>
* @section PTemp	Perpheials Used
* @subsection TP	Master Synchronous Serial Port (MSSP)
* @image html BTemp.jpg "On Board Temperature Sensor; TC74"
* <br> 
* <p> The Master Synchronous Serial Port (MSSP) module is a serial interface useful for 
* communication with other peripheral or microcontroller devices. The MSSP module can operate
* in one of two modes: </p> 
* <ul> <li> Serial Peripheral Interface (SPI) </li> <li> Inter-Integrated Circuit (I2C) </li> </ul>
* <br> Note* We will be using I2C
*
* @subsection RTemp	Reading the Temperature Display
* @image html TempR.jpg "Temperature"
* <ul> <li> <b> A] </b> Display current temperature at given unit of measurement </li>
* <li> <b> B] </b> Change the unit of measurement .
* </li> </ul>
* @subsection Math	MATH 
* <br> Equation for Celcius: Temperature @ Positive Value (SSPBUF < 128)= SSPBUF [Direct value from TC74] 
* <br> <br> Equation for Celcius: Temperature @ Negative Value (SSPBUF > 128)= (256 - SSPBUF)*(-1) 
* <br> <br> Fahrenheit = [(9/5)*Celsius] + 32
* <hr>
* @section Setup	MSSP Register Setup
* @subsection SSPCON1 SSP Control Register
* <ul> 
* <li> <b> WCOL:</b>  <0> - No Collision [Master mode]</li>
* <li> <b> SSPOV:</b> <0> - No overflow [I2C Mode]</li>
* <li> <b> SSPEN: </b> <1> - Enable the serial port and configures the SDA and SCL pins as the source of the serial port pins </li>
* <li> <b> CKP:</b> <0> - Unused in this mode [I2C Master]</li>
* <li> <b> SSPM:<3:0></b> <1000> - I2C Master Mode, Clock = Fosc/(4*(SSPADD+1))</li>
* </ul>
* @subsection SSPADD MSSP Address and Baud Rate Register
* <ul> 
* <li> <b> ADD <7:0> :</b> <00001001> - Setup for FOSC = (4MHz), FCY = (1MHz), Fclock = (100 kHz)</li>
* </ul>
* @image html Baud_Math.png
* <br> <hr>
* @subpage BGBD	<br>
* @subpage MSSPBD	<br>
* @subpage MSSPR <br>
* @subpage I2CMW
*/
/**
* @page BGBD Baud Rate Generator Block Diagram 
* @image html BG.png
*/
/**
* @page MSSPBD MSSP [I2C] Block Diagram  
* @image html MSSP_M.png 
* <hr>
* @image html MSSP_S.png
*/
/**
* @page MSSPR	Used MSSP Registers
* @image html SSPCON1.png 
* <hr>
* @image html SSPADD.png
*/
/**
* @page I2CMW	I2C Example Waveform
* @image html I2C_MW.png
*/
/**
* @page Clock Real Time Clock Operation
* @section ClockMenu Real Time Clock Menu
* @image html ClockMenu.jpg "Clock Menu"
* <br> <p> The program will enter this state:<br>
* <ul>
* <li> <b> a) </b> After exiting Temperature Menu State </li>
* </ul> 
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RA4: [Next] </b> - Move to the next state. [Voltmeter] </li>
* <li> <b> RB0: [Now] </b> -  Enter Clock Set Function</li>
* </ul><hr>
*
* @section ClockSet Set Real time Clock
* @image html ClockSet.jpg "Real Time Clock Set Menu"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> RA4: [Set] </b> - Enter Clock Setup. </li>
* <li> <b> RB0: [Menu] </b> - Return to Clock State Menu</li>
* </ul>
* @subsection Select	Select to set Minutes or Hours
* @image html Select.jpg "Set Minutes or Hours"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> A] RA4: [HR] </b> - Enter Hour Setup. </li>
* <li> <b> B] RB0: [MIN] </b> - Enter Minutes Setup </li>
* </ul>
* <hr>
* @subsection HR	Increment Hours
* @image html HrsInc.jpg "Increment the Hours"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> A] RA4:++ </b> - Increment Hours. </li>
* <li> <b> B] RB0:Next </b> - Go to Decrement Hours.</li>
* </ul>
* @subsection HRD	Decrement Hours
* @image html HrsDec.jpg "Decrement the Hours"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> A] RA4:-- </b> - Decrement Hours. </li>
* <li> <b> B] RB0:Next </b> - Go to Real Time Clock Set Menu.</li>
* </ul>
* <hr>
* @subsection Min	Increment Minutes
* @image html MinInc.jpg "Increment the Minutes"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> A] RA4:++ </b> - Increment Minutes. </li>
* <li> <b> B] RB0:Next </b> - Go to Decrement Minutes.</li>
* </ul>
* @subsection MIND	Decrement Minutes
* @image html MinDec.jpg "Decrement the Minutes"
* <p> The User has the following choices:<br>
* <ul>
* <li> <b> A] RA4:-- </b> - Decrement Minutes. </li>
* <li> <b> B] RB0:Next </b> - Go to Real Time Clock Set Menu.</li>
* </ul>
* <hr>
* @section PRTC	Perpheials Used
* @subsection RTCP	Timer 1 supplied by External Crystal [32kHz]
* @image html BEXC.jpg "On Board External Crystal [32kHz]"
* <br> 
* <p> The Timer 1 module is a 16-bit timer/counter which uses the register pair [TMR1H:TMR1L],
*  can use a dedicated 32kHz oscillator circuit, Interrupt on overflow, Wake-up on overflow function and more!</p> 
* <br> <br> <b> Note*: </b> In this program Timer1 is used to keep an accurate 1 Secound count by using the interrupt on overflow feature.
* <hr>
* @section SetupT	Real Time Clock Setup
* @subsection T1CON	Timer 1 Control Register
* <ul> 
* <li> <b> TMR1CS <1:0>:</b>  <10> - Timer1 clock source is the Crystal oscillator on T1OSI/T1OSO </li>
* <li> <b> T1CKPS<1:0>:</b> <00> - 1:1 Prescale value</li>
* <li> <b> T1OSCEN: </b> <1> - Dedicated Timer1 oscillator circuit enabled </li>
* <li> <b> nT1SYNC:</b> <0> - Do not synchronize external clock input</li>
* <li> <b> TMR1ON:</b> <1> - Enables Timer 1</li>
* </ul>
* <br> <hr>
* @subpage TimerBD	<br>
* @subpage TimerR	
*/
/**
* @page TimerBD	Timer 1 Block Diagram
* @image html Timer1BD.png
*/
/**
* @page TimerR	Timer 1 Control Register
* @image html Timer1R.png
*/
/**
* @page Serial RS232 Serial Communication
*/
/**
* @page SoftwareLicense Software License Agreement
*
* IMPORTANT: 
* MICROCHIP IS WILLING TO LICENSE THE ACCOMPANYING SOFTWARE AND DOCUMENTATION TO YOU ONLY ON THE CONDITION THAT YOU ACCEPT ALL OF THE FOLLOWING TERMS. TO ACCEPT THE TERMS OF THIS LICENSE, CLICK "I ACCEPT" AND PROCEED WITH THE DOWNLOAD OR INSTALL. IF YOU DO NOT ACCEPT THESE LICENSE TERMS, CLICK "I DO NOT ACCEPT," AND DO NOT DOWNLOAD OR INSTALL THIS SOFTWARE. 
*  
* NON-EXCLUSIVE SOFTWARE LICENSE AGREEMENT FOR ACCOMPANYING MICROCHIP SOFTWARE AND DOCUMENTATION INCLUDING, BUT NOT LIMITED TO: <br>
* GRAPHICS LIBRARY SOFTWARE, IrDA STACK SOFTWARE, MCHPFSUSB STACK SOFTWARE, MEMORY DISK DRIVE FILE SYSTEM SOFTWARE, mTOUCH<sup>TM</sup> CAPACITIVE LIBRARY SOFTWARE, PC PROGRAMS, SMART CARD LIBRARY SOFTWARE, TCP/IP STACK SOFTWARE, AND/OR MiWi<sup>TM</sup> DE SOFTWARE <br><br>
*  
* IMPORTANT - READ CAREFULLY. 
*  
* This Nonexclusive Software License Agreement ("Agreement") is a contract between you, your heirs, successors and assigns ("Licensee") and Microchip Technology Incorporated, a Delaware corporation, with a principal place of business at 2355 W. Chandler Blvd., Chandler, AZ 85224-6199, and its subsidiary, Microchip Technology (Barbados) Incorporated (collectively, "Microchip") for the accompanying Microchip software including, but not limited to, Graphics Library Software, IrDA Stack Software, MCHPFSUSB Stack Software, Memory Disk Drive File System Software, mTouch<sup>TM</sup> Capacitive Library Software, PC programs, Smart Card Library Software, TCP/IP Stack Software, MiWi<sup>TM</sup> DE Software, and any updates thereto (collectively, the "Software"), and accompanying documentation, including images and any other graphic resources provided by Microchip ("Documentation"). 
*  
* The Software and Documentation are licensed under this Agreement and not sold. U.S. copyright laws, international copyright treaties, and other intellectual property laws and treaties protect the Software and Documentation. Microchip reserves all rights not expressly granted to Licensee in this Agreement. 
*  
* 1. License and Sublicense Grant. 
*  <ul>
*  <li>(a) Definitions. As used in this Agreement, the following capitalized terms will have the meanings defined below: 
*   <ul>
*   <li>(i) "Microchip Products" means Microchip microcontrollers, Microchip digital signal controllers, or other Microchip products that use or implement the Software. 
*   <li>(ii) "Licensee Products" means Licensee products that use or incorporate Microchip Products. 
*   <li>(iii) "Object Code" means the Software computer programming code that is in binary form (including related documentation, if any), and error corrections, improvements, modifications, and updates. 
*   <li>(iv) "Source Code" means the Software computer programming code that may be printed out or displayed in human readable form (including related programmer comments and documentation, if any), and error corrections, improvements, modifications, and updates. 
*   <li>(v) "Third Party" means Licensee's agents, representatives, consultants, clients, customers, or contract manufacturers. 
*   <li>(vi) "Third Party Products" means Third Party products that use or incorporate Microchip Products. 
*   </ul>
*  <li>(b) Software License Grant. Microchip grants strictly to Licensee a non-exclusive, non-transferable, worldwide license to use the Software, as described below: 
*   <ul>
*   <li>(i) Graphics Library Software, MCHPFSUSB Stack Software, Memory Disk Drive File System Software, mTouch<sup>TM</sup> Capacitive Library Software, Smart Card Library, TCP/IP Stack Software, and other accompanying Microchip software not otherwise expressly addressed in Section 1(b)(ii) or Section 1(b)(iii) below: 
*    <ul>
*    <li>(1) Licensee may use, modify, copy, and distribute the Software identified in the subheading of this Section 1(b)(i) when such Software is embedded in a Microchip Product that is either integrated into Licensee Product or Third Party Product pursuant to Section 1(d) below. 
*    <li>(2) Further, with respect to the TCP/IP Stack Software, Licensee may only port the ENC28J60.c, ENC28J60.h, ENCX24J600.c, and ENCX24J600.h driver source files to a non-Microchip device used in conjunction with a Microchip ethernet controller for the sole purpose of interfacing with such ethernet controller. 
*    </ul>
*   <li>(ii) IrDA Stack Software: 
*    <ul>
*    <li>(1) Licensee may install the IrDA Stack Software on a single computer and use with Microchip Products; and 
*    <li>(2) Use, modify, copy, and distribute the device driver source files of the IrDA Stack Software ("Device Drivers"); provided that (x) such Device Drivers are only used with Microchip Products, and (y) no Open Source Components (defined in Section 2(c) below) are incorporated into such Device Drivers. 
*    </ul>
*   <li>(iii) PC Programs: 
*    <ul>
*    <li>(1) Licensee may install, use, modify (if Microchip provides Source Code), copy, and distribute the PC programs on an unlimited number of computers; provided that (x) such PC programs are used with Microchip products, and (y) the following conditions are met when Licensee redistributes any PC programs: <br><br>
* "Copyright (c) Microchip Technology Inc. All rights reserved. Microchip PC programs are provided for your use with Microchip products only. <br><br>
* Redistributions and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: 
*     <ul>
*     <li>Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. 
*     <li>Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. 
*     <li>Neither the name of Microchip nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. 
*     </ul>
* THIS SOFTWARE IS PROVIDED BY MICROCHIP ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE." 
*    </ul>
*   <li>(iv) MiWi<sup>TM</sup> DE Software: Licensee may use, modify, copy and distribute the Software only when embedded on a Microchip Product and used with either a Microchip radio frequency transceiver or UBEC UZ2400 radio frequency transceiver, which are integrated into Licensee Products or Third Party Products pursuant to Section 1(d) below.<br><br>
* For purposes of clarity, Licensee may NOT embed the Software identified in Section 1(b)(i) (including derivatives or modifications thereof) on a non-Microchip Product, except as described in Section 1(b)(i)(2). Licensee may NOT use, copy, modify or distribute the IrDA Stack Software, except as described in Section 1(b)(ii)(2) above (relating to Device Drivers) and Section 1(d) below (relating to sublicenses). Licensee may NOT distribute Source Code or Object Code of the Software on a standalone basis, except as described in Section 1(b)(iii) above (relating to PC programs) and Section 1(d) below (relating to sublicense rights). For the MiWi<sup>TM</sup> DE Software, Licensee may NOT embed the Software (including derivatives or modifications thereof) on a non-Microchip Product, use the Software with a radio frequency transceiver other than the Microchip and UBEC transceivers listed in Section 1(b)(iv), or distribute the Software (in Source Code or Object Code) except as described in Section 1(d) below. 
*   </ul>
*  <li>(c) Documentation License Grant. Microchip grants strictly to Licensee a non-exclusive, non-transferable, worldwide license to use the Documentation in support of Licensee's authorized use of the Software. 
*  <li>(d) Sublicense Grants. Licensee may grant a sublicense to a Third Party to use the Software as described in this subparagraph (d) provided that Licensee first obtains such Third Party's agreement in writing to comply with the terms of this Agreement: 
*   <ul>
*   <li>(i) Graphics Library Software, MCHPFSUSB Stack Software, Memory Disk Drive File System Software, mTouch<sup>TM</sup> Capacitive Library Software, Smart Card Library, TCP/IP Stack Software, MiWi<sup>TM</sup> DE Software, and other accompanying Microchip software not otherwise expressly addressed in Section 1(b)(iii) above or Section 1(d)(ii) below: <br><br>
* With respect to Software identified in this Section 1(d)(i), Third Party may: 
*    <ul>
*    <li>(1) Modify Source Code for Licensee. 
*    <li>(2) Program Software into Microchip Products for Licensee. 
*    <li>(3) Use the Software to develop and/or manufacture Licensee Products. 
*    <li>(4) Use the Software to develop and/or manufacture Third Party Products where either: (x) the sublicensed Software contains Source Code modified or otherwise optimized by Licensee for integration into Third Party Products; and/or (y) the sublicensed Software is programmed into Microchip Products by Licensee on behalf of such Third Party. 
*    <li>(5) Use the Documentation in support of Third Party's authorized use of the Software in conformance with this Section 1(d)(i). 
*    </ul>
*   <li>(ii) IrDA Stack Software: <br><br>
* With respect to IrDA Stack Software, Third Party may: 
*    <ul>
*    <li>(1) Modify ONLY Device Drivers for Licensee. 
*    <li>(2) Program Software into Microchip Products for Licensee. 
*    <li>(3) Use the Documentation in support of Third Party's authorized use of the Software in conformance with this Section 1(d)(ii). 
*    </ul>
*   </ul>
*  <li>(e) Audit. Microchip's authorized representatives will have the right to reasonably inspect, announced or unannounced, and its sole and absolute discretion, Licensee's premises and to audit Licensee's records and inventory of Licensee Products, whether located on Licensee's premises or elsewhere at any time, in order to ensure Licensee's adherence to the terms of this Agreement. 
*  </ul>
* 2. Third Party Requirements; Open Source Components.<br><br>Licensee acknowledges that it is Licensee's responsibility to comply with any third party license terms or requirements applicable to the use of such third party software, specifications, systems, or tools. Microchip is not responsible and will not be held responsible in any manner for Licensee's failure to comply with such applicable terms or requirements. 
* <ul>
* <li>(a) IrDA Stack Software. With respect to the IrDA Stack Software, Licensee further acknowledges that it is Licensee's responsibility to obtain a copy of, to familiarize itself fully with, and comply with the requirements of the Infrared Data Association, especially regarding the use of IrDA specifications and development of IrDA-compliant products. At the time of this Software release, it is Microchip's understanding that Licensee may obtain a copy of IrDA specifications from the IrDA website by either paying an access fee or becoming a member of the Infrared Data Association. For more information go to www.irda.org. 
* <li>(b) Memory Disk Drive File System Software. With respect to the Memory Disk Drive File Systems Software, Licensee further acknowledges that it is Licensee's responsibility to obtain a copy of, familiarize itself fully with, and comply with the requirements and licensing obligations applicable to the use of flash-based media and FAT files systems available from Compact Flash Association, SD Card Association, Multi Media Card Association, and Microsoft Corporation. 
* <li>(c) Open Source Components. Notwithstanding the license grant in Section 1 above, Licensee further acknowledges that certain components of the Software may be covered by so-called "open source" software licenses ("Open Source Components"). Open Source Components means any software licenses approved as open source licenses by the Open Source Initiative or any substantially similar licenses, including without limitation any license that, as a condition of distribution of the software licensed under such license, requires that the distributor make the software available in source code format. 
* To the extent required by the licenses covering Open Source Components, the terms of such license will apply in lieu of the terms of this Agreement, and Microchip hereby represents and warrants that the licenses granted to such Open Source Components will be no less broad than the license granted in Section 1. To the extent the terms of the licenses applicable to Open Source Components prohibit any of the restrictions in this Agreement with respect to such Open Source Components, such restrictions will not apply to such Open Source Component. 
* For purposes of clarity: 
* QT Compiled PC Program: The MCHPFSUSB Stack Software is accompanied by a certain PC program developed by Microchip that was developed using the QT 3 compiler ("QT Compiled PC Program"). Such QT 3 compiler is governed by the GNU General Public License version 2 ("GPL"). Accordingly, Microchip offers such QT Compiled PC Program, including Source Code for such program, under the terms of GPL version 2 as well. For copies of the GPL version 2, please go to http://www.fsf.org. 
* JPEG Software: Independent JPEG Group's software and accompanying third party files including, but not limited to, GIF compressed format files are governed by the terms described in IJG's license. This license is posted in the "IJG License.pdf" file located at: &gt;Installed Folder&lt;\\Microchip\\Image Decoders. 
* <li>(d) Google Static Maps API: Google Static Maps API and Google server usage are governed by the legal notices, terms and conditions posted on the Google website at www.google.com, including but not limited to the Static Maps API Developer Guide, the Legal Notices for Google Maps/Google Earth and Google Maps/Google Earth API, the Google Maps/Google Earth Terms of Service, and the Google Maps/Google Earth API Terms of Service. 
* </ul>
* 3. Licensee Obligations. 
* <ul>
* <li>(a) Licensee will ensure Third Party compliance with the terms of this Agreement, and will be liable for any breach of this Agreement committed by such Third Party. 
* <li>(b) Licensee will not: (i) engage in unauthorized use, modification, disclosure or distribution of Software or Documentation, or its derivatives; (ii) use all or any portion of the Software, Documentation, or its derivatives except in conjunction with Microchip Products or Third Party Products; or (iii) reverse engineer (by disassembly, decompilation or otherwise) Software or any portion thereof. 
* <li>(c) Licensee may not remove or alter any Microchip copyright or other proprietary rights notice posted in any portion of the Software or Documentation. 
* <li>(d) Licensee will defend, indemnify and hold Microchip and its subsidiaries harmless from and against any and all claims, costs, damages, expenses (including reasonable attorney's fees), liabilities, and losses, including without limitation product liability claims, directly or indirectly arising from or related to: (i) the use, modification, disclosure or distribution of the Software, Documentation, or any intellectual property rights related thereto; (ii) the use, sale and distribution of Licensee Products or Third Party Products; and (iii) breach of of this Agreement. THIS SECTION 3(d) STATES THE SOLE AND EXCLUSIVE LIABILITY OF THE PARTIES FOR INTELLECTUAL PROPERTY INFRINGEMENT. 
* </ul>
* 4. Confidentiality.
* <ul>
* <li>(a) Licensee agrees that the Software (including but not limited to the Source Code, Object Code and library files) and its derivatives, Documentation and underlying inventions, algorithms, know-how and ideas relating to the Software and the Documentation are proprietary information belonging to Microchip and its licensors ("Proprietary Information"). Except as expressly and unambiguously allowed herein, Licensee will hold in confidence and not use or disclose any Proprietary Information and will similarly bind its employees and Third Party(ies) in writing. Proprietary Information will not include information that: (i) is in or enters the public domain without breach of this Agreement and through no fault of the receiving party; (ii) the receiving party was legally in possession of prior to receiving it; (iii) the receiving party can demonstrate was developed by the receiving party independently and without use of or reference to the disclosing party's Proprietary Information; or (iv) the receiving party receives from a third party without restriction on disclosure. If Licensee is required to disclose Proprietary Information by law, court order, or government agency, such disclosure will not be deemed a breach of this Agreement provided that Licensee: (x) gives Microchip prompt notice of such requirement in order to allow Microchip to object or limit such disclosure; (y) cooperates with Microchip to protect Proprietary Information; and (z) Licensee complies with any protective order in place and discloses only the information required by process of law.
* <li>(b) Licensee agrees that the provisions of this Agreement regarding unauthorized use and nondisclosure of the Software, Documentation and related Proprietary Rights are necessary to protect the legitimate business interests of Microchip and its licensors and that monetary damages alone cannot adequately compensate Microchip or its licensors if such provisions are violated. Licensee, therefore, agrees that if Microchip alleges that Licensee or Third Party has breached or violated such provision then Microchip will have the right to petition for injunctive relief, without the requirement for the posting of a bond, in addition to all other remedies at law or in equity.
* </ul>
* 5. Ownership of Proprietary Rights.
* <ul>
* <li>(a) Microchip and its licensors retain all right, title and interest in and to the Software and Documentation ("Proprietary Rights") including, but not limited to: (i) patent, copyright, trade secret and other intellectual property rights in the Software, Documentation, and underlying technology; (ii) the Software as implemented in any device or system, including all hardware and software implementations of the Software technology (expressly excluding Licensee and Third Party code developed and used in conformance with this Agreement solely to interface with the Software and Licensee Products and/or Third Party Products); and (iii) all copies and derivative works thereof (by whomever produced). Further, copies and derivative works will be considered works made for hire with ownership vesting in Microchip on creation. To the extent such modifications and derivatives do not qualify as a "work for hire," Licensee hereby irrevocably transfers, assigns and conveys the exclusive copyright thereof to Microchip, free and clear of any and all liens, claims or other encumbrances, to the fullest extent permitted by law. Licensee and Third Party use of such modifications and derivatives is limited to the license rights described in Sections 1 and 2 above.
* <li>(b) Licensee will have no right to sell, assign or otherwise transfer all or any portion of the Software, Documentation, or any related intellectual property rights except as expressly set forth in this Agreement.
* </ul>
* 6. Termination of Agreement. Without prejudice to any other rights, this Agreement terminates immediately, without notice by Microchip, upon a failure by Licensee or Third Party to comply with any provision of this Agreement. Further, Microchip may also terminate this Agreement upon reasonable belief that Licensee or Third Party failed to comply with this Agreement. Upon termination, Licensee and Third Party will immediately stop using the Software, Documentation, and derivatives thereof, and immediately destroy all such copies.<br><br>
* 7. Warranties and Disclaimers. THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. MICROCHIP AND ITS LICENSORS ASSUME NO RESPONSIBILITY FOR THE ACCURACY, RELIABILITY OR APPLICATION OF THE SOFTWARE OR DOCUMENTATION. MICROCHIP AND ITS LICENSORS DO NOT WARRANT THAT THE SOFTWARE WILL MEET REQUIREMENTS OF LICENSEE OR THIRD PARTY, BE UNINTERRUPTED OR ERROR-FREE. MICROCHIP AND ITS LICENSORS HAVE NO OBLIGATION TO CORRECT ANY DEFECTS IN THE SOFTWARE. LICENSEE AND THIRD PARTY ASSUME THE ENTIRE RISK ARISING OUT OF USE OR PERFORMANCE OF THE SOFTWARE AND DOCUMENTATION PROVIDED UNDER THIS AGREEMENT.<br><br>
* 8. Limited Liability. IN NO EVENT WILL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL OR EQUITABLE THEORY FOR ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT LIMITED TO INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS. The aggregate and cumulative liability of Microchip and its licensors for damages hereunder will in no event exceed $1000 or the amount Licensee paid Microchip for the Software and Documentation, whichever is greater. Licensee acknowledges that the foregoing limitations are reasonable and an essential part of this Agreement.<br><br>
* 9. General.
* <ul>
* <li>(a) Governing Law, Venue and Waiver of Trial by Jury. THIS AGREEMENT WILL BE GOVERNED BY AND CONSTRUED UNDER THE LAWS OF THE STATE OF ARIZONA AND THE UNITED STATES WITHOUT REGARD TO CONFLICTS OF LAWS PROVISIONS. Licensee agrees that any disputes arising out of or related to this Agreement, Software or Documentation will be brought in the courts of the State of Arizona. The parties agree to waive their rights to a jury trial in actions relating to this Agreement.
* <li>(b) Attorneys' Fees. If either the Microchip or Licensee employs attorneys to enforce any rights arising out of or relating to this Agreement, the prevailing party will be entitled to recover its reasonable attorneys' fees, costs and other expenses.
* <li>(c) Entire Agreement. This Agreement will constitute the entire agreement between the parties with respect to the subject matter hereof. It will not be modified except by a written agreement signed by an authorized representative of the Microchip.
* <li>(d) Severability. If any provision of this Agreement will be held by a court of competent jurisdiction to be illegal, invalid or unenforceable, that provision will be limited or eliminated to the minimum extent necessary so that this Agreement will otherwise remain in full force and effect and enforceable.
* <li>(e) Waiver. No waiver of any breach of any provision of this Agreement will constitute a waiver of any prior, concurrent or subsequent breach of the same or any other provisions hereof, and no waiver will be effective unless made in writing and signed by an authorized representative of the waiving party.
* <li>(f) Export Regulation. Licensee agrees to comply with all export laws and restrictions and regulations of the Department of Commerce or other United States or foreign agency or authority.
* <li>(g) Survival. The indemnities, obligations of confidentiality, and limitations on liability described herein, and any right of action for breach of this Agreement prior to termination, will survive any termination of this Agreement.
* <li>(h) Assignment. Neither this Agreement nor any rights, licenses or obligations hereunder, may be assigned by Licensee without the prior written approval of Microchip except pursuant to a merger, sale of all assets of Licensee or other corporate reorganization, provided that assignee agrees in writing to be bound by the Agreement.
* <li>(i) Restricted Rights. Use, duplication or disclosure by the United States Government is subject to restrictions set forth in subparagraphs (a) through (d) of the Commercial Computer-Restricted Rights clause of FAR 52.227-19 when applicable, or in subparagraph (c)(1)(ii) of the Rights in Technical Data and Computer Software clause at DFARS 252.227-7013, and in similar clauses in the NASA FAR Supplement. Contractor/manufacturer is Microchip Technology Inc., 2355 W. Chandler Blvd., Chandler, AZ 85225-6199.
* </ul><br><br>
* If Licensee has any questions about this Agreement, please write to Microchip Technology Inc., 2355 W. Chandler Blvd., Chandler, AZ 85224-6199 USA. ATTN: Marketing.
*
* Copyright &copy; 2010 Microchip Technology Inc. All rights reserved.
*
* License Rev. No. 01-101910 
* 
*/
/**
* @page RequiredIncludes Required Hardware Include Files
*
*
*
*
*/
/**
* @page StateMachine @image html State_Machine.png "PICDEM 2 Plus State Machine"
* @dot 
digraph bsm {

    rankdir=TB;

    overlap = false;

    compound=true;

    remincross=true;

    nodesep=0.4;

    ranksep=.4;
	
	size = "12,14"

	// setup the nodes

    Start        	[label="Start/Restart", shape = "tripleoctagon", fillcolor ="deepskyblue2", color = "dodgerblue4", style ="filled"];

    Initial      	[label="Initial\nState", shape = "doublecircle", fillcolor ="deepskyblue2", color = "dodgerblue4", style ="filled"];

    Voltmeter      	[label="Voltmeter\nState", shape = "doublecircle", fillcolor ="deepskyblue2", color = "dodgerblue4", style ="filled"];

    Buzzer    		[label="Buzzer\nState", shape = "doublecircle", fillcolor ="deepskyblue2", color = "dodgerblue4", style ="filled"];

    Temperature 	[label="Temperature\nIndicator\nState", shape = "doublecircle", fillcolor ="deepskyblue2", color = "dodgerblue4", style ="filled"];

    Clock       	[label="Clock\nState", shape = "doublecircle", fillcolor ="deepskyblue2", color = "dodgerblue4", style ="filled"];

    DispVolt    	[label="Display\nVoltage", shape = "trapezium", fillcolor ="chartreuse2", color = "darkgreen", style ="filled"];

    DispBuzz      	[label="Display/Play\nSound", shape = "trapezium", fillcolor ="chartreuse2", color = "darkgreen", style ="filled"];
	
	DispTemp    	[label="Display\nTemperature", shape = "trapezium", fillcolor ="chartreuse2", color = "darkgreen", style ="filled"];

    DispTime      	[label="Display\nTime", shape = "trapezium", fillcolor ="chartreuse2", color = "darkgreen", style ="filled"];
	
	SetClock      	[label="Set \n\n Clock", shape = "invtriangle", fillcolor ="gold1", color = "goldenrod4", style ="filled"];
	
	Hours    		[label="Adjust\nHours\n", shape = "egg", fillcolor ="orchid", color = "deeppink4", style ="filled"];

    Minutes      	[label="Adjust\nMinutes\n", shape = "egg", fillcolor ="orchid", color = "deeppink4", style ="filled"];

	subgraph cluster0 
	{
		style = filled;
		color = white;
		Voltmeter -> Buzzer -> Temperature -> Clock [color = white];
	}
	
	subgraph cluster1 
	{
		style = filled;
		color = white;
		DispVolt -> DispBuzz -> DispTemp -> DispTime [color = white];
	}
	
	subgraph cluster2
	{
		style = filled;
		color = white;
		SetClock [color = white]
	}
	
	subgraph cluster3
	{

		style = filled;
		color = white;
		Hours -> Minutes [color = white]
	}
	
    // describe the connections	

    Start -> Initial   		[label=" [Initial Configuration] ",  arrowhead="open", style="dotted"];

    Initial -> Voltmeter 	[label=" [Splash Menu]\n 2 Secound Wait ",  arrowhead="open", style="dotted"];

    Voltmeter -> Buzzer    	[label=" [RA4]; Next State ",  arrowhead="open", style="dotted"];
	
	Buzzer -> Temperature   [label=" [RA4]; Next State ",  arrowhead="open", style="dotted"];
		
	Temperature -> Clock    [label=" [RA4]; Next State ",  arrowhead="open", style="dotted"];
	
	Voltmeter -> DispVolt	[label = " [RB0]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	DispVolt -> DispVolt	[label = " [POT]; ADC Conversion ", color = "purple", fontcolor ="purple", arrowhead ="diamond"];
	
	DispVolt -> Voltmeter 	[label = " [RB0]; Return ",  style="dashed", color = "red", fontcolor ="red", arrowhead = "empty"];
	
	Buzzer -> DispBuzz		[label = " [RB0]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	DispBuzz -> DispBuzz	[label = " [RA4]; Period Change ", color = "purple", fontcolor ="purple", arrowhead ="diamond"];
	
	DispBuzz -> Buzzer 		[label = " [RB0]; Return ",  style="dashed", color = "red", fontcolor ="red", arrowhead = "empty"];
	
	Temperature -> DispTemp	[label = " [RB0]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	DispTemp -> DispTemp	[label = " [RA4];\n TC74 Temperature Data", color = "purple", fontcolor ="purple", arrowhead ="diamond"];
	
	DispTemp -> Temperature [label = " [RB0]; Return ",  style="dashed", color = "red", fontcolor ="red", arrowhead = "empty"];
	
	Clock -> DispTime		[label = " [RB0]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	DispTime -> SetClock	[label = " [RA4]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	DispTime -> Clock 		[label = " [RB0]; Return ",  style="dashed", color = "red", fontcolor ="red", arrowhead = "empty"];
	
	SetClock -> Minutes		[label = " [RB0]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	SetClock -> Hours		[label = " [RA4]; Select ", style="bold", color ="blue", fontcolor ="blue", arrowhead = "empty"];
	
	Hours -> Hours			[label = " [RA4]; Change Time ", color = "purple", fontcolor ="purple", arrowhead ="diamond"];

	Minutes -> Minutes		[label = " [RA4]; Change Time ", color = "purple", fontcolor ="purple", arrowhead ="diamond"];
	
	Hours -> DispTime		[label = " [RB0]; Return ", style="dashed", color = "red", fontcolor ="red", arrowhead = "empty"];

	Minutes -> DispTime		[label = " [RB0]; Return ", style="dashed", color = "red", fontcolor ="red", arrowhead = "empty"];
	
	Clock -> Voltmeter		[label = " [RA4]; Next State ", style="dotted"];
  
 }
@enddot
*/